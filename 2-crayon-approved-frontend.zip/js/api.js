/* All backend access. Same contract as the shipped app.js: fetch(API+'/web/'+path), Bearer token, credentials omitted. */
import { API, WEB_API, SESSION_KEY } from './config.js';
import { state, emit } from './bus.js';

export class ApiError extends Error {
  constructor(message, httpStatus, kind) { super(message); this.httpStatus = httpStatus; this.kind = kind; }
}
const doFetch = (...a) => (window.__crayonFetch || fetch)(...a);

export function saveSession(token, expires) {
  try { localStorage.setItem(SESSION_KEY, JSON.stringify({ token, expires })); } catch { emit('toast', 'Browser storage is blocked, so this sign-in will not survive closing the tab.'); }
}
export function dropSession() { try { localStorage.removeItem(SESSION_KEY); } catch { /* storage may be unavailable */ } }
export function readSession() {
  try { return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); } catch { dropSession(); return null; }
}

/* A wake-up or network hiccup: the request may not have reached the server. */
export const transient = e => e instanceof TypeError || e?.name === 'SyntaxError' || e?.httpStatus >= 500;
export const isBusy = e => /Crayon is busy|Wait before sending another/i.test(e?.message || '');
export const isDailyCap = e => /Daily free-tier message limit/i.test(e?.message || '');
export const isOriginBlock = e => /Origin not allowed/i.test(e?.message || '');

export async function call(path, body) {
  let r, j;
  try {
    r = await doFetch(API + '/web/' + path, {
      method: body === undefined ? 'GET' : 'POST', credentials: 'omit',
      headers: { 'Content-Type': 'application/json', ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) })
    });
  } catch (e) { setHost('sleepy'); throw e; }
  try { j = await r.json(); } catch (e) { setHost('sleepy'); if (r.ok) throw e; j = {}; }
  if (r.status >= 500) setHost('sleepy'); else setHost('awake');
  if (!r.ok) {
    if (r.status === 401 && path !== 'session') emit('signed-out');
    const err = new ApiError(j.error || 'Request not confirmed.', r.status);
    throw err;
  }
  return j;
}

function setHost(h) { if (state.host !== h) { state.host = h; emit('host', h); } }

/* Anonymous Crayon-Web layer (optional; needs CORS on that service) */
export async function webApi(path, opts = {}) {
  return doFetch(WEB_API + path, { credentials: 'omit', ...opts });
}

/* Plain-language line for anything that is not a confirmed result. Never exposes raw server/transport errors. */
export function inCharacter(e) {
  const m = e?.message || '';
  if (isDailyCap(e)) return 'That is all of today’s free messages. Crayon rests until tomorrow, and everything you saved is safe.';
  if (isBusy(e)) return 'Crayon has its hands full. Your message is in line and will go through on its own.';
  if (isOriginBlock(e)) return 'This address is not on Crayon’s guest list yet. Open Crayon from its home page, or ask the team to allow this site.';
  if (transient(e)) return 'Crayon’s host is waking up (free hosting naps). Your message is safe in line.';
  if (/not found/i.test(m)) return 'I could not find that request. Nothing was changed.';
  if (m && m.length < 220 && !/traceback|exception|undefined|\bNaN\b|TypeError|Failed to fetch/i.test(m)) return m;
  return 'Crayon tripped on that one. Nothing was changed.';
}
