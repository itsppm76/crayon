/* Sign-in flows: Telegram (OIDC code+verifier popup), Google (popup), email (Firebase ID token), link + merge reviews.
   Contract identical to the shipped app: /web/auth/start, login-poll, google/login-start|link-start|link-poll|link-confirm,
   email/config|session|link-preview|link-confirm, account-merge/start|poll|confirm. */
import { el, icon, randomId, challenge } from './util.js';
import { API } from './config.js';
import { state, emit } from './bus.js';
import { call, inCharacter } from './api.js';
import { applySession } from './session.js';
import { sheet, field, button, status } from './ui.js';

let popup = null, verifier = '', loginTimer = null, loginBusy = false, loginDeadline = 0, loginMode = 'telegram', emailClientPromise = null;

export async function startLogin(mode) {
  loginMode = mode;
  popup = window.open('about:blank', 'crayon-login', 'width=520,height=720');
  if (!popup) { status('Allow the sign-in popup, then try again.'); return; }
  clearTimeout(loginTimer); verifier = randomId();
  const ch = await challenge(verifier);
  try {
    popup.location = mode === 'telegram' ? API + '/web/auth/start?challenge=' + encodeURIComponent(ch)
      : (await call(mode === 'merge' ? 'account-merge/start' : 'google/' + (mode === 'link' ? 'link-start' : 'login-start'), { challenge: ch })).url;
  } catch (e) { popup.close(); verifier = ''; status(inCharacter(e)); return; }
  status(mode === 'merge' ? 'Approve your Telegram identity, then come back for an exact consolidation review. Nothing moves before you confirm.'
    : mode === 'telegram' ? 'Approve Crayon in Telegram, then come back to this tab.'
    : mode === 'link' ? 'Choose Google, then return here to review the exact account link.'
    : 'Choose your Google account. Existing Telegram users can link Google from the account menu while signed in.');
  const current = verifier; loginDeadline = Date.now() + 300000;
  loginTimer = setTimeout(() => finishLogin(current, loginDeadline), 1000);
}

async function finishLogin(v, deadline) {
  if (v !== verifier || loginBusy) return;
  loginBusy = true;
  try {
    const j = await call(loginMode === 'merge' ? 'account-merge/poll' : loginMode === 'link' ? 'google/link-poll' : 'login-poll', { verifier: v });
    if (v !== verifier) return;
    if (j.pending) {
      if (Date.now() > deadline) { verifier = ''; status('That sign-in timed out. Try again.'); }
      else loginTimer = setTimeout(() => finishLogin(v, deadline), 3000);
      return;
    }
    verifier = ''; clearTimeout(loginTimer);
    if (loginMode === 'merge') return mergeReview(j);
    if (loginMode === 'link') return linkReview(j.text, j, 'google/link-confirm', 'Link your Google account', 'Link these accounts');
    applySession(j); status('Your Crayon account is connected.'); emit('toast', 'Signed in. Welcome back.');
  } catch (err) {
    status(inCharacter(err));
    if (v === verifier && Date.now() < deadline) loginTimer = setTimeout(() => finishLogin(v, deadline), 5000);
  } finally { loginBusy = false; }
}
window.addEventListener('message', e => {
  if (e.origin !== API || e.source !== popup || !verifier) return;
  if (e.data?.type === 'crayon-login-error') { verifier = ''; clearTimeout(loginTimer); status(String(e.data.error || 'Sign-in stopped. Try again.')); return; }
  if (e.data?.type !== 'crayon-login') return;
  clearTimeout(loginTimer); finishLogin(verifier, loginDeadline);
});
document.addEventListener('visibilitychange', () => { if (!document.hidden && verifier) { clearTimeout(loginTimer); finishLogin(verifier, loginDeadline); } });

function linkReview(text, j, path, title, yes) {
  sheet(title, (s, close) => {
    const pre = el('pre', { class: 'review' }, text); s.append(pre);
    const b1 = button(yes, async () => { b1.disabled = b2.disabled = true; try { const r = await call(path, { review_id: j.review_id, hash: j.hash, decision: 'confirm' }); status(r.text); close(); } catch (e) { pre.textContent = inCharacter(e); b1.disabled = b2.disabled = false; } }, 'btn btn-primary');
    const b2 = button('Cancel', async () => { try { await call(path, { review_id: j.review_id, hash: j.hash, decision: 'cancel' }); } catch { /* cancelling is best-effort */ } close(); }, 'btn');
    s.append(el('div', { class: 'row' }, b1, b2));
  });
}

function mergeReview(j) {
  sheet('Review account consolidation', (s, close) => {
    const pre = el('pre', { class: 'review' }, j.text); s.append(pre);
    const choices = {};
    for (const c of j.conflicts || []) {
      const sel = el('select', { class: 'select', onchange: () => { if (sel.value) choices[c.key] = sel.value; else delete choices[c.key]; } },
        el('option', { value: '' }, 'Choose one explicitly'), el('option', { value: 'source' }, 'Keep source: ' + c.source), el('option', { value: 'target' }, 'Keep Telegram: ' + c.target));
      s.append(el('div', { class: 'field' }, el('label', {}, 'Fact ' + c.key), sel));
    }
    const go = async decision => {
      if (decision === 'confirm' && Object.keys(choices).length !== (j.conflicts || []).length) { status('Choose a value for every fact conflict.'); return; }
      btns.forEach(b => b.disabled = true);
      try { const r = await call('account-merge/confirm', { review_id: j.review_id, hash: j.hash, decision, choices }); if (decision === 'confirm') emit('signed-out'); status(r.text); close(); }
      catch (e) { pre.textContent = inCharacter(e) + ' No merge was completed. Start a fresh review before trying again.'; btns.forEach(b => b.disabled = false); }
    };
    const b1 = button('Merge exactly as reviewed', () => go('confirm'), 'btn btn-primary'), b2 = button('Keep separate accounts', () => go('cancel'), 'btn');
    const btns = [b1, b2]; s.append(el('div', { class: 'row' }, b1, b2));
  });
}
export const startMerge = () => state.token ? startLogin('merge') : status('Sign in first.');
export const startLink = () => state.token ? startLogin('link') : status('Sign in first.');

/* ---------- email (Firebase direct; Crayon only receives the ID token) ---------- */
export async function emailLogin(email, linkMode) {
  email = (email || '').trim();
  if (!/^\S+@\S+\.\S+$/.test(email)) { status('Enter a valid email address.'); return; }
  try {
    const config = await call('email/config');
    if (!emailClientPromise) emailClientPromise = window.__crayonEmailClient ? Promise.resolve(window.__crayonEmailClient) : import('./email-auth.js').then(m => m.emailClient(config));
    const client = await emailClientPromise;
    sheet(linkMode ? 'Link an email login' : 'Sign in with email', (s, close) => {
      s.append(el('p', { class: 'fine' }, `${email}. Your password goes straight to Firebase and never to Crayon. Existing Google or Telegram users should link an email while signed in; matching addresses never merge accounts by themselves.`));
      const pw = field('Password', { type: 'password', attrs: { autocomplete: 'current-password' } });
      const note = el('p', { role: 'status', class: 'fine' });
      s.append(pw.wrap, note);
      const row = el('div', { class: 'row' }); const all = [];
      const act = (text, fn, cls = 'btn') => { const b = button(text, async () => { all.forEach(x => x.disabled = true); try { await fn(); } catch { note.textContent = 'Email sign-in was not completed. Check your details or try again in a bit.'; } finally { all.forEach(x => x.disabled = false); pw.input.value = ''; } }, cls); all.push(b); row.append(b); return b; };
      async function finish() {
        const idToken = await client.token();
        if (linkMode) {
          const j = await call('email/link-preview', { id_token: idToken });
          close(); await client.clear();
          linkReview(j.text, j, 'email/link-confirm', 'Review email link', 'Link this email'); return;
        }
        const j = await call('email/session', { id_token: idToken });
        close(); await client.clear(); applySession(j); status('Your Crayon account is connected.'); emit('toast', 'Signed in. Welcome back.');
      }
      act('Sign in', async () => { const u = await client.signIn(email, pw.input.value); if (u.emailVerified) await finish(); else note.textContent = 'Verify your email first: use Send verification email, then I verified my email.'; }, 'btn btn-primary');
      act('Create account', async () => { if (pw.input.value.length < 15) { note.textContent = 'Use a password with at least 15 characters.'; return; } await client.create(email, pw.input.value); note.textContent = 'Account created. Send the verification email before opening Crayon.'; });
      act('Send verification email', async () => { await client.verify(); note.textContent = 'Verification email sent. Check your inbox, then come back here.'; });
      act('I verified my email', finish);
      act('Reset password', async () => { await client.reset(email); note.textContent = 'If this email has an account, a reset email is on its way.'; });
      act('Delete email login', async () => {
        await client.signIn(email, pw.input.value);
        sheet('Delete this email login', (r, closeR) => {
          r.append(el('p', {}, `Permanently delete the Firebase email and password login for ${email}? This does not delete Crayon memory or history, or your other login methods. If this is your only login you may lose access to your Crayon data. Deleting Crayon data is not available on the web yet.`));
          const y = button('Delete this email login', async () => { y.disabled = true; try { await client.deleteProvider(); await call('logout', {}).catch(() => {}); emit('signed-out'); status('The email login was deleted. Crayon data was not.'); closeR(); close(); } catch { r.append(el('p', { class: 'fine' }, 'Deletion was not confirmed. Sign in again before retrying.')); y.disabled = false; } }, 'btn btn-danger');
          r.append(el('div', { class: 'row' }, y, button('Keep it', async () => { await client.clear(); closeR(); close(); }, 'btn')));
        });
      }, 'btn btn-quiet');
      act('Cancel', async () => { await client.clear(); close(); }, 'btn btn-quiet');
      s.append(row);
    });
  } catch (e) { emailClientPromise = null; status(inCharacter(e)); }
}
