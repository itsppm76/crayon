/* Endpoints and constants. Contract: crayon-v1 /web/* is primary; Crayon-Web /api/* is optional + anonymous. */
export const API = 'https://crayon-v1.onrender.com';
export const WEB_API = 'https://crayon-web.onrender.com';
export const SESSION_KEY = 'crayon.web.session';
export const THEME_KEY = 'crayon.theme';
export const POLL_MS = 2000;
export const POLL_MAX = 150;
export const DEMO = new URLSearchParams(location.search).get('demo');
