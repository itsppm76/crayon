/* The conversation thread: messages, the Pondering panel, Work-complete strip, sources, artifacts. */
import { $, el, icon, iconBtn, linkedText, splitSources, hostOf, b64ToBlobUrl, fmtTime } from './util.js';
import { mascot, setMascot } from './mascot.js';
import { STATES, SETTLED, steps } from './progress.js';
import { emit } from './bus.js';

export const log = $('#log');
export const scroller = $('#scroll');
const urls = [];

export function scrollEnd(force = false) {
  const nearEnd = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight < 240;
  if (force || nearEnd) scroller.scrollTo({ top: scroller.scrollHeight });
}
export function clearThread() {
  urls.forEach(URL.revokeObjectURL); urls.length = 0;
  if ('speechSynthesis' in window) speechSynthesis.cancel();
  log.replaceChildren();
  emit('thread-cleared');
}
const lastIsAi = () => log.lastElementChild?.classList.contains('ai');

/* ---- wax tick: a hand-drawn check that draws itself ---- */
export function waxTick() {
  const s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  s.setAttribute('viewBox', '0 0 20 20'); s.setAttribute('aria-hidden', 'true');
  s.innerHTML = '<path class="wax" d="M3.5 10.8 C5.2 12.3 6.3 13.6 7.6 15.6 C10 11.2 13.4 7.4 16.6 4.4"/><path class="wax b" d="M4 11.6 C5.6 12.8 6.6 14 7.8 16 C10.4 11.6 13.6 8.2 17 5.2"/>';
  return s;
}

/* ---- user + assistant messages ---- */
export function addUser(text, { quote } = {}) {
  const b = el('div', { class: 'bubble' });
  if (quote) b.append(el('div', { class: 'quoted' }, quote.slice(0, 140)));
  b.append(document.createTextNode(text));
  const row = el('div', { class: 'msg user' }, b);
  log.append(row); scrollEnd(true);
  return { row, bubble: b };
}

function actions(bubbleText) {
  const bar = el('div', { class: 'message-actions' });
  if ('speechSynthesis' in window) {
    const read = iconBtn('speaker-high', 'Read aloud', () => {
      if (read.dataset.reading === 'yes') { speechSynthesis.cancel(); read.dataset.reading = 'no'; read.setAttribute('aria-pressed', 'false'); return; }
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(bubbleText);
      const done = () => { read.dataset.reading = 'no'; read.setAttribute('aria-pressed', 'false'); };
      u.onend = done; u.onerror = () => { done(); emit('status', 'This device could not read that aloud.'); };
      speechSynthesis.speak(u); read.dataset.reading = 'yes'; read.setAttribute('aria-pressed', 'true');
    }, 'sm');
    bar.append(read);
  }
  const copy = iconBtn('copy', 'Copy text', async () => {
    try { await navigator.clipboard.writeText(bubbleText); copy.replaceChildren(icon('check')); copy.title = 'Copied'; setTimeout(() => { copy.replaceChildren(icon('copy')); copy.title = 'Copy text'; }, 1600); }
    catch { emit('status', 'Clipboard is blocked here. Select the text to copy it.'); }
  }, 'sm');
  const reply = iconBtn('arrow-bend-up-left', 'Reply to this', () => emit('quote', bubbleText), 'sm');
  bar.append(copy, reply);
  return bar;
}

const MONEY = /(?:₹|Rs\.?\s?)[\d,]+(?:\.\d+)?|\b\d+(?:\.\d+)?\s?°\s?C/g;
function dataCard(text) {
  if (!/Source:/i.test(text)) return null;
  // skip thresholds like "under ₹20,000": only figures the answer reports
  const hits = [...text.matchAll(MONEY)].filter(m => !/(under|below|up ?to|within|budget( of)?|max(imum)?|over|above)\s*$/i.test(text.slice(Math.max(0, m.index - 14), m.index))).slice(0, 2);
  if (!hits.length) return null;
  const c = el('div', { class: 'datacard', role: 'group', 'aria-label': 'Figures from the sourced answer' }, el('span', { class: 'lbl' }, 'From the sourced answer'));
  hits.forEach(h => c.append(el('strong', {}, h[0])));
  c.append(el('small', {}, 'Forecast or advertised price where stated. Details and source below.'));
  return c;
}

function sourcesBlock(list) {
  if (!list.length) return null;
  const d = el('details', { class: 'sources' }, el('summary', {}, icon('globe', 'sm'), `Sources (${list.length})`, icon('caret-down', 'sm')));
  const chips = el('div', { class: 'chips' });
  list.slice(0, 8).forEach(u => chips.append(el('a', { class: 'chip', href: u, target: '_blank', rel: 'noopener noreferrer', title: u }, icon('link', 'sm'), el('span', {}, hostOf(u)))));
  d.append(chips); return d;
}

export function addAi(text, { time, plain } = {}) {
  const cont = lastIsAi();
  const { text: body, sources } = plain ? { text, sources: [] } : splitSources(text);
  const bubble = el('div', { class: 'bubble' });
  if (body) linkedText(bubble, body);
  const wrap = el('div', { class: 'body' });
  const card = !plain && dataCard(text); if (card) wrap.append(card);
  wrap.append(bubble);
  const src = sourcesBlock(sources); if (src) wrap.append(src);
  if (text) {
    const bar = actions(body || text);
    if (time) { const d = new Date(time); if (!Number.isNaN(d.getTime())) bar.prepend(el('time', { class: 'message-time', datetime: d.toISOString() }, d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }))); }
    wrap.append(bar);
  }
  const row = el('div', { class: 'msg ai' + (cont ? ' cont' : '') }, mascot('idle', 'av'), wrap);
  log.append(row); scrollEnd();
  return { row, bubble, wrap };
}

/* ---- artifacts ---- */
export function addArtifact(x, host) {
  const target = host || addAi('', { plain: true }).wrap;
  const url = b64ToBlobUrl(x.data, x.mime); urls.push(url);
  if (['image/png', 'image/jpeg', 'image/webp'].includes(x.mime)) {
    const img = el('img', { src: url, alt: x.name, class: 'artifact-image', tabIndex: 0, onclick: () => emit('canvas', { kind: 'image', url, name: x.name }) });
    target.append(img);
  }
  if (x.mime.startsWith('audio/')) target.append(el('audio', { controls: true, src: url }));
  if (x.mime === 'text/csv' || /\.csv$/i.test(x.name)) {
    atob(x.data); // validate
    const text = new TextDecoder().decode(Uint8Array.from(atob(x.data), c => c.charCodeAt(0)));
    target.append(el('button', { class: 'chip', type: 'button', onclick: () => emit('canvas', { kind: 'csv', text, name: x.name }) }, icon('chart-bar', 'sm'), 'Open table and chart'));
  }
  target.append(el('a', { class: 'artifact', href: url, download: x.name }, icon('download-simple', 'sm'), 'Download ' + x.name));
  scrollEnd();
}

export function renderItem(x, handlers = {}) {
  if (x.kind === 'mcp_review') { handlers.mcpReview?.(x); return; }
  if (x.kind === 'text') addAi(x.text);
  else if (x.kind === 'artifact') addArtifact(x);
}

/* ---- the Pondering panel ---- */
export function createRun() {
  const mark = el('span', { class: 'p-mark' }, icon('pencil-simple'));
  const title = el('span', { class: 'p-title' }, 'Pondering');
  const time = el('span', { class: 'p-time', 'aria-hidden': 'true' }, '00:00');
  const count = el('span', { class: 'p-count' }, 'Starting');
  const ol = el('ol', { class: 'p-steps', 'aria-label': 'Recorded work steps' });
  const note = el('p', { class: 'p-note' }, 'Only steps Crayon actually recorded appear here.');
  const d = el('details', { class: 'ponder', open: true, dataset: { state: 'queued' } },
    el('summary', {}, mark, title, time, count, icon('caret-right', 'sm p-caret')), ol, note, el('div', { class: 'wax-run' }));
  const face = mascot('thinking', 'av');
  const draft = el('div', { class: 'draft hide', 'aria-label': 'Draft being checked' });
  const body = el('div', { class: 'body' }, d, draft);
  const row = el('div', { class: 'msg ai run' + (lastIsAi() ? ' cont' : '') }, face, body);
  log.append(row); scrollEnd(true);

  const t0 = Date.now(); let settled = false;
  const tick = setInterval(() => { time.textContent = fmtTime((Date.now() - t0) / 1000); }, 1000);
  const run = {
    row, body, face, ponder: d,
    elapsed: () => (Date.now() - t0) / 1000,
    update(events, state) {
      if (settled) return;
      const list = steps(events);
      d.dataset.state = state;
      setMascot(face, state === 'queued' ? 'thinking' : 'working');
      title.textContent = STATES[state] === 'Working' || state === 'queued' ? 'Pondering' : STATES[state] || 'Pondering';
      count.textContent = list.length ? `${list.filter(s => s.state === 'done').length}/${list.length} steps` : (state === 'queued' ? 'In line' : 'Starting');
      const have = new Map([...ol.children].map(li => [li.dataset.id, li]));
      for (const s of list) {
        let li = have.get(s.id);
        if (!li) { li = el('li', { dataset: { id: s.id } }, el('span', { class: 'tick' }), el('span', { class: 'lbl' })); ol.append(li); }
        else if (li.dataset.s === s.state) continue;
        const tk = li.querySelector('.tick'); tk.replaceChildren();
        if (s.state === 'done') tk.append(waxTick());
        li.dataset.s = s.state; li.querySelector('.lbl').textContent = s.label;
        li.setAttribute('aria-label', `${s.label}: ${STATES[s.state]}`);
      }
      [...ol.children].forEach(li => { if (!list.some(s => s.id === li.dataset.id)) li.remove(); });
    },
    setDraft(text) {
      if (!text || settled) return;
      draft.classList.remove('hide'); draft.textContent = text; draft.append(el('span', { class: 'caret', 'aria-hidden': 'true' }));
      scrollEnd();
    },
    /* settle: collapse the panel, keep the recorded steps, return elapsed seconds */
    settle(state, events, opts = {}) {
      if (settled) return; settled = true; clearInterval(tick);
      const secs = opts.history ? 0 : Math.max(1, Math.round(run.elapsed()));
      d.dataset.state = state;
      const list = steps(events);
      if (list.length) run.renderFinal(list);
      title.textContent = opts.history ? 'Recorded work' : state === 'done' ? `Pondered for ${secs}s` : STATES[state] || 'Finished';
      count.textContent = list.length ? `${list.length} step${list.length === 1 ? '' : 's'}` : '';
      mark.replaceChildren(state === 'done' ? waxTick() : icon('hourglass'));
      time.hidden = true; draft.remove(); d.open = false;
      note.textContent = 'Recorded work events. Nothing was sent twice.';
      setMascot(face, state === 'done' ? 'done' : 'idle');
      if (!list.length) d.querySelector('summary').style.pointerEvents = 'none';
      return { secs, count: list.length };
    },
    renderFinal(list) {
      ol.replaceChildren();
      for (const s of list) {
        const tk = el('span', { class: 'tick' }); if (s.state === 'done') tk.append(waxTick());
        ol.append(el('li', { dataset: { s: s.state, id: s.id }, 'aria-label': `${s.label}: ${STATES[s.state]}` }, tk, el('span', { class: 'lbl' }, s.label)));
      }
    },
    remove() { settled = true; clearInterval(tick); row.remove(); }
  };
  run.update([], 'queued');
  return run;
}

/* Work complete / stopped strip, shown after the answer */
export function workStrip(state, { secs, count } = {}) {
  const label = STATES[state] || STATES.unknown;
  const bits = [];
  if (count) bits.push(`${count} step${count === 1 ? '' : 's'}`);
  if (secs) bits.push(`${secs}s`);
  const s = el('div', { class: 'workdone', role: 'status', dataset: { s: state } }, state === 'done' ? waxTick() : icon('warning', 'sm'), el('span', {}, label), bits.length ? el('span', { class: 'meta' }, bits.join(' · ')) : null);
  s.querySelector('svg')?.setAttribute('width', '18');
  const wrap = el('div', { class: 'msg ai cont' }, mascot('idle', 'av'), el('div', { class: 'body' }, s));
  log.append(wrap); scrollEnd();
  return s;
}

/* ---- the in-character busy line + visible queue ---- */
export function busyNote({ title, text, queue = [] }) {
  const ol = el('ol', { class: 'queue', 'aria-label': 'Messages waiting' });
  const note = el('div', { class: 'busy', role: 'status' }, mascot('sleepy'), el('div', {}, el('h3', {}, title), el('p', {}, text), ol));
  const api = {
    node: note,
    setQueue(items) {
      ol.replaceChildren();
      items.forEach((q, i) => ol.append(el('li', {}, el('span', { class: 'pos' }, '#' + (i + 1)), el('span', { class: 'txt' }, q.text), el('span', { class: 'eta' }, q.eta || ''))));
      ol.hidden = !items.length;
    },
    set(t, p) { note.querySelector('h3').textContent = t; note.querySelector('p').textContent = p; },
    remove() { note.closest('.msg')?.remove(); }
  };
  api.setQueue(queue);
  log.append(el('div', { class: 'msg ai cont' }, mascot('idle', 'av'), el('div', { class: 'body' }, note)));
  scrollEnd();
  return api;
}

/* history message from /web/history or /web/conversation-history */
export function renderHistory(m) {
  if (m.role === 'user') { addUser(m.text); return; }
  const ev = m.work_events || [];
  if (ev.length) {
    const run = createRun();
    const st = ev.some(e => e.state === 'blocked') ? 'blocked' : 'done';
    run.settle(st, ev, { history: true });
  }
  const { wrap } = addAi(m.text, { time: m.time });
  for (const x of m.media || []) addArtifact(x, wrap);
  if (m.media_missing) wrap.append(el('div', { class: 'media-missing' }, 'Original Telegram media was not kept by Crayon. Upload it again to view or analyze it.'));
}
