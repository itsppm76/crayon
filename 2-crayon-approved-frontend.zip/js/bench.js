/* Workbench: the right-hand pane. Panels are thin views over real /web/* routes. */
import { $, el, icon, iconBtn, fmtTime } from './util.js';
import { state, emit, on } from './bus.js';
import { call, inCharacter } from './api.js';
import { sheet, field, button, busyBtn, status, toast } from './ui.js';
import { mascot } from './mascot.js';
import * as Chat from './chat.js';
import * as Approval from './approval.js';
import * as Composer from './composer.js';
import { renderItem } from './thread.js';
import { parseCsv, tableEl, chartEl } from './canvas.js';

const body = $('#bench-body'), tabs = $('#bench-tabs'), title = $('#bench-title');
const TABS = [
  ['do', 'Do something', 'sparkle'], ['routines', 'Routines', 'clock-countdown'], ['notifications', 'Notifications', 'bell'],
  ['rooms', 'Shared rooms', 'users-three'], ['connections', 'Connections', 'plug'], ['activity', 'Web activity', 'lightning'],
  ['plugins', 'Plugins', 'cube'], ['canvas', 'Canvas', 'chart-bar']
];
let current = null, canvasData = null, mcpPrefill = '';

export function openBench(tab = 'do', data) {
  document.body.classList.add('bench-open'); $('#bench-toggle').setAttribute('aria-pressed', 'true');
  if (data?.prefill) mcpPrefill = data.prefill;
  select(tab);
}
export function closeBench() { document.body.classList.remove('bench-open'); $('#bench-toggle').setAttribute('aria-pressed', 'false'); }
on('close-bench', closeBench);
on('open-bench', ({ tab, prefill }) => openBench(tab, { prefill }));
$('#bench-close').onclick = closeBench;
$('#bench-toggle').onclick = () => document.body.classList.contains('bench-open') ? closeBench() : openBench(current || 'do');
document.querySelectorAll('[data-bench]').forEach(b => b.onclick = () => { openBench(b.dataset.bench); emit('close-rail'); });
on('close-rail', () => document.body.classList.remove('rail-open'));
on('canvas', d => { canvasData = d; $('#bench-dot').classList.remove('hide'); openBench('canvas'); });

function select(id) {
  current = id; const t = TABS.find(x => x[0] === id) || TABS[0];
  title.textContent = t[1];
  tabs.replaceChildren(...TABS.map(([k, label, ic]) => el('button', { class: 'tabbtn', role: 'tab', type: 'button', 'aria-selected': String(k === id), onclick: () => select(k) }, icon(ic, 'sm'), label)));
  tabs.querySelector('[aria-selected=true]')?.scrollIntoView({ inline: 'center', block: 'nearest' });
  body.replaceChildren();
  if (id === 'canvas') $('#bench-dot').classList.add('hide');
  if (!state.token && id !== 'canvas') { body.append(signedOutNote()); return; }
  const loading = el('div', { class: 'list' }, ...[1, 2, 3].map(() => el('div', { class: 'row-item' }, el('div', { class: 'skeleton', style: 'width:100%;height:18px' }))));
  const render = PANELS[id]; body.append(loading);
  Promise.resolve().then(render).then(node => { if (current !== id) return; body.replaceChildren(node); }).catch(e => { if (current !== id) return; body.replaceChildren(softFail(e, () => select(id))); });
}
function signedOutNote() {
  return el('div', { class: 'empty' }, mascot('sleepy'), el('b', {}, 'Sign in to use this'), el('p', {}, 'The workbench shows your own account’s data, so it stays locked until you sign in.'));
}
function softFail(e, retry) {
  return el('div', { class: 'empty' }, mascot('sleepy'), el('b', {}, 'Crayon is taking a breather'), el('p', {}, inCharacter(e)), button('Try again', retry, 'btn btn-sm', 'arrow-clockwise'));
}
const section = (t, ...kids) => el('section', { class: 'sec' }, el('h3', { class: 'section-title' }, t), ...kids);
const when = s => { const d = new Date(String(s).replace(' ', 'T')); return Number.isNaN(d.getTime()) ? String(s) : d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); };

const PANELS = {
  /* ---- shortcuts that speak natural language to the agent ---- */
  async do() {
    const go = (text) => { emit('close-bench-small'); Chat.ask(text); };
    const row = (ic, label, sub, text) => el('button', { type: 'button', onclick: () => go(text) }, icon(ic), el('span', {}, label, el('small', {}, sub)));
    const wrap = el('div', {});
    wrap.append(
      el('p', { class: 'callout' }, 'Everything here is just a shortcut for something you can also type. Crayon answers in the chat and keeps the same memory on Telegram.'),
      section('Your things', el('div', { class: 'do-grid' },
        row('checks', 'Tasks and goals', 'See and update what is on your list', 'my tasks'),
        row('brain', 'Memory', 'What Crayon remembers about you', 'show my memory'),
        row('alarm', 'Reminders', 'Everything scheduled', 'my reminders'),
        row('notebook', 'Notes', 'Notes you asked Crayon to keep', 'show my notes'))),
      section('Work', el('div', { class: 'do-grid' },
        row('kanban', 'Work queue', 'Background jobs and their state', '/work list'),
        row('monitor', 'Computer jobs', 'Browser tasks with screenshots', '/computer status'),
        el('button', { type: 'button', onclick: forgetFlow }, icon('trash'), el('span', {}, 'Forget one saved fact', el('small', {}, 'Reviewed first, removes only that fact'))))),
      section('Play and help', el('div', { class: 'do-grid' },
        row('play', 'Quick quiz', 'A short quiz with Crayon', '/play quiz'),
        row('question', 'Guess a number', 'A small game', '/play guess'),
        row('question', 'What can you do?', 'Commands and examples', '/help'))));
    return wrap;
  },

  /* ---- routines: real quiet hours + digest + recent events ---- */
  async routines() {
    const s = await call('proactive'); let n = { notifications: [] }; try { n = await call('notifications'); } catch { /* optional */ }
    const wrap = el('div', {});
    const strip = el('div', { class: 'daystrip', role: 'img', 'aria-label': `Quiet hours ${s.quiet_start}:00 to ${s.quiet_end}:00, ${s.timezone}` });
    const qs = Number(s.quiet_start), qe = Number(s.quiet_end);
    const span = (a, b) => el('div', { class: 'quiet', style: `left:${a / 24 * 100}%;width:${(b - a) / 24 * 100}%` });
    if (qs !== qe) { if (qs < qe) strip.append(span(qs, qe)); else { strip.append(span(qs, 24)); strip.append(span(0, qe)); } }
    const nowH = new Date().getHours() + new Date().getMinutes() / 60; strip.append(el('div', { class: 'now', style: `left:${nowH / 24 * 100}%` }));
    const active = field('Task check-ins', {}); const sel = el('select', { class: 'select', id: active.input.id }, el('option', { value: 'on' }, 'On'), el('option', { value: 'off' }, 'Off')); sel.value = s.proactive ? 'on' : 'off'; active.input.replaceWith(sel);
    const digest = field('Digest', {}); const dsel = el('select', { class: 'select', id: digest.input.id }, ...['off', 'morning', 'evening', 'both'].map(v => el('option', { value: v }, v[0].toUpperCase() + v.slice(1)))); dsel.value = s.digest; digest.input.replaceWith(dsel);
    const q1 = field('Quiet from (hour 0–23)', { type: 'number', value: s.quiet_start, attrs: { min: 0, max: 23 } }), q2 = field('Quiet until (hour 0–23)', { type: 'number', value: s.quiet_end, attrs: { min: 0, max: 23 } });
    const msg = el('p', { class: 'fine', role: 'status' }, `Delivery: ${s.delivery}. Timezone: ${s.timezone}. Timing is best-effort on free hosting.`);
    const save = button('Save with private in-app delivery', () => busyBtn(save, async () => {
      try { const r = await call('proactive', { proactive: sel.value === 'on', digest: dsel.value, quiet_start: Number(q1.input.value), quiet_end: Number(q2.input.value), accept: true }); msg.textContent = r.text; toast('Routine saved.'); }
      catch (e) { msg.textContent = inCharacter(e); }
    }), 'btn btn-primary');
    wrap.append(
      section('Your day', strip, el('div', { class: 'hours', 'aria-hidden': 'true' }, ['0', '6', '12', '18', '24'].map(h => el('span', {}, h + 'h'))), el('p', { class: 'fine' }, 'Blue = quiet hours. The dark line is now.')),
      section('Check-ins and digests', el('p', { class: 'callout' }, 'Saving switches delivery to in-app Notifications for this account. Telegram /proactive or /digest switches it back to Telegram.'), active.wrap, digest.wrap, el('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:12px' }, q1.wrap, q2.wrap), msg, save),
      section('Recent results', timelineOf(n.notifications)));
    return wrap;
  },

  async notifications() {
    const n = await call('notifications'); const unread = n.notifications.filter(x => !x.seen).length; setBadge(unread);
    if (!n.notifications.length) return el('div', { class: 'empty' }, mascot('idle'), el('b', {}, 'Nothing new'), el('p', {}, 'Reminders and finished background work land here. No phone, email or push message is implied.'));
    const wrap = el('div', {}, el('p', { class: 'fine' }, 'Reminder and work results, stored privately. Nothing leaves your account.'));
    const list = el('ol', { class: 'timeline' });
    for (const x of n.notifications) {
      const li = el('li', { dataset: { seen: String(!!x.seen) } }, el('time', {}, when(x.created_at)), el('p', {}, x.text));
      if (!x.seen) { const b = button('Mark read', () => busyBtn(b, async () => { await call('notification-seen', { id: x.id }); li.dataset.seen = 'true'; b.remove(); setBadge(Math.max(0, countUnread() - 1)); }), 'btn btn-sm btn-quiet'); li.append(b); }
      list.append(li);
    }
    wrap.append(list); return wrap;
  },

  /* ---- shared rooms ---- */
  async rooms() {
    const j = await call('rooms'); const wrap = el('div', {});
    wrap.append(el('p', { class: 'callout warn' }, j.notice));
    const list = el('div', { class: 'list' });
    j.rooms.forEach(r => list.append(el('div', { class: 'row-item' }, icon('users-three'), el('div', { class: 'txt' }, el('b', {}, r.name), el('span', {}, r.is_owner ? 'You own this room' : 'Member')), button('Open', () => roomView(r), 'btn btn-sm'))));
    if (!j.rooms.length) list.append(el('div', { class: 'empty' }, el('b', {}, 'No rooms yet'), el('p', {}, 'Create one to chat with friends and Crayon about public information.')));
    const name = field('Room name'); const ok = el('label', { class: 'check' }, el('input', { type: 'checkbox' }), 'I understand everyone in the room sees every message, including people who join later.');
    const out = el('div', {}); const create = button('Create room', () => busyBtn(create, async () => {
      if (!ok.firstChild.checked) { out.replaceChildren(el('p', { class: 'fine' }, 'Tick the box to confirm you have read who can see this room.')); return; }
      try { const r = await call('rooms/create', { name: name.input.value, accept: true }); out.replaceChildren(el('p', { class: 'fine' }, 'Room created. Share this invite only with the people you intend.'), el('div', { class: 'token-box' }, r.invite)); roomView(r); }
      catch (e) { out.replaceChildren(el('p', { class: 'fine' }, inCharacter(e))); }
    }), 'btn btn-primary');
    const inv = field('Invite token'); const joinOut = el('div', {});
    const inspect = button('Review invitation', () => busyBtn(inspect, async () => {
      try {
        const r = await call('rooms/inspect', { invite: inv.input.value });
        const j2 = button('Join this shared audience', () => busyBtn(j2, async () => { try { const jr = await call('rooms/join', { invite: inv.input.value, accept: true }); roomView(jr); select('rooms'); } catch (e) { joinOut.append(el('p', { class: 'fine' }, inCharacter(e))); } }), 'btn btn-primary');
        joinOut.replaceChildren(el('b', {}, r.name), el('p', { class: 'fine' }, r.notice), j2);
      } catch (e) { joinOut.replaceChildren(el('p', { class: 'fine' }, inCharacter(e))); }
    }), 'btn');
    wrap.append(section('Your rooms', list), section('Start a room', name.wrap, ok, create, out), section('Join with an invite', inv.wrap, inspect, joinOut));
    return wrap;
  },

  /* ---- connections, private reads, reviewed actions ---- */
  async connections() {
    const c = await call('connections'); const wrap = el('div', {});
    wrap.append(el('p', { class: 'callout' }, 'Each member connects their own accounts. Google access is limited to approved testers while the app is in Google’s Testing mode. Nothing sends without an exact review.'));
    const stat = (label, v) => el('div', { class: 'row-item' }, el('div', { class: 'txt' }, el('b', {}, label), el('span', {}, v || 'Not connected')), el('span', { class: 'status-dot', dataset: { s: v ? 'live' : 'off' } }));
    wrap.append(section('Status', el('div', { class: 'list' }, stat('Gmail and Calendar', c.google), stat('Docs, Sheets and Slides', c.workspace))));
    const linkOut = el('div', {});
    const conn = (provider, label) => button(label, () => busyBtn(conn_[provider], async () => { try { const r = await call('connect', { provider }); linkOut.replaceChildren(el('p', { class: 'fine' }, r.text), el('a', { class: 'btn btn-primary', href: r.url, target: '_blank', rel: 'noopener' }, icon('arrow-square-out', 'sm'), 'Open the connection page')); } catch (e) { linkOut.replaceChildren(el('p', { class: 'fine' }, inCharacter(e))); } }), 'btn');
    const conn_ = {}; const provs = [['google', 'Connect Gmail and Calendar'], ['workspace', 'Connect Docs, Sheets and Slides'], ['github', 'Connect GitHub (public identity only)'], ...(c.calendar_owner ? [['calendar_write', 'Turn on calendar writes']] : [])];
    const row1 = el('div', { class: 'row', style: 'display:flex;flex-wrap:wrap;gap:8px' }); provs.forEach(([p, l]) => { conn_[p] = conn(p, l); row1.append(conn_[p]); });
    wrap.append(section('Connect', row1, linkOut));
    const reads = [['inbox', 'Inbox headers', 'mail'], ['email_read', 'Read one email', 'envelope'], ['doc', 'Read a Doc', 'file-text'], ['sheet', 'Read a Sheet', 'table'], ['github', 'Public GitHub digest', 'github-logo'], ...(c.calendar_owner ? [['calendar', 'Read Calendar', 'calendar-blank']] : [])];
    wrap.append(section('Read privately', el('p', { class: 'fine' }, 'Direct reads. They skip the AI and are not saved to your chat.'), el('div', { class: 'do-grid' }, reads.map(([k, l, ic]) => el('button', { type: 'button', onclick: () => privateRead(k, l) }, icon(ic === 'mail' ? 'envelope' : ic), el('span', {}, l))))));
    const acts = [['workspace_create', 'Create a Doc, Sheet or Slides', 'file-text'], ['email', 'Prepare an email', 'envelope'], ['sheet', 'Prepare a Sheet update', 'table'], ['form', 'Review a free HTML form', 'note-pencil'], ...(c.calendar_owner ? [['calendar', 'Prepare a calendar event', 'calendar-blank']] : [])];
    wrap.append(section('Prepare an action', el('p', { class: 'fine' }, 'You always get an exact preview first. Nothing is sent or written from these forms.'), el('div', { class: 'do-grid' }, acts.map(([k, l, ic]) => el('button', { type: 'button', onclick: () => actionForm(k, l) }, icon(ic), el('span', {}, l))))));
    return wrap;
  },

  async activity() {
    const a = await call('activity'); const wrap = el('div', {}, el('p', { class: 'fine' }, 'Your latest 30 web requests, including files Crayon made. Original uploads are not kept.'));
    if (!a.activity.length) return el('div', { class: 'empty' }, mascot('idle'), el('b', {}, 'No activity yet'), el('p', {}, 'Ask Crayon something and the recorded steps show up here.'));
    const list = el('ol', { class: 'timeline' });
    for (const r of a.activity) {
      const steps = (r.progress || []).slice(-5).map(p => el('li', { style: 'list-style:none;padding:0;margin:0;font-size:.8125rem;color:var(--ink-3)' }, (p.state === 'done' ? '✓ ' : p.state === 'blocked' ? '! ' : '· ') + p.label));
      const li = el('li', {}, el('time', {}, when(r.created_at) + ' · ' + (r.state || '')), ...steps);
      (r.items || []).filter(x => x.kind === 'text').slice(0, 1).forEach(x => li.append(el('p', {}, x.text.slice(0, 220) + (x.text.length > 220 ? '…' : ''))));
      list.append(li);
    }
    wrap.append(list); return wrap;
  },

  async plugins() {
    const s = await call('mcp'); const wrap = el('div', {}, el('p', { class: 'callout warn' }, s.notice));
    const list = el('div', { class: 'list' });
    Object.entries(s.connectors).forEach(([name, c]) => { const row = el('div', { class: 'row-item' }, icon('plug'), el('div', { class: 'txt' }, el('b', {}, name), el('span', {}, c.tools.map(t => t.name).join(', '))), button('Disconnect', async () => { await call('mcp', { action: 'remove', name }); row.remove(); }, 'btn btn-sm btn-danger')); list.append(row); });
    if (!Object.keys(s.connectors).length) list.append(el('div', { class: 'empty' }, el('b', {}, 'No connectors yet'), el('p', {}, 'A connector lets Crayon call tools on a public HTTPS MCP server, one reviewed call at a time.')));
    const name = field('Connector name'), url = field('Public HTTPS MCP endpoint', { value: mcpPrefill });
    if (mcpPrefill) { try { name.input.value = new URL(mcpPrefill).hostname.replace(/[^a-z0-9_-]/gi, '-').slice(0, 40); } catch { /* ignore bad prefill */ } mcpPrefill = ''; }
    const consent = el('label', { class: 'check' }, el('input', { type: 'checkbox' }), 'I trust this server and accept the risk that what I ask it to do may be shared with it.');
    const out = el('p', { class: 'fine', role: 'status' });
    const add = button('Connect and discover tools', () => busyBtn(add, async () => { try { const r = await call('mcp', { action: 'add', name: name.input.value, url: url.input.value, accept: consent.firstChild.checked }); out.textContent = `Connected ${r.name}. Tools: ${r.tools.map(t => t.name).join(', ')}. Ask in chat to use one; each call needs your review.`; } catch (e) { out.textContent = inCharacter(e); } }), 'btn btn-primary');
    wrap.append(section('Connected', list), section('Add a connector', name.wrap, url.wrap, consent, add, out)); return wrap;
  },

  async canvas() {
    const d = canvasData;
    if (!d) return el('div', { class: 'empty' }, mascot('idle'), el('b', {}, 'Nothing on the canvas'), el('p', {}, 'Tables, charts and screenshots that Crayon makes open here when you tap them in the chat.'));
    if (d.kind === 'image') return el('div', {}, el('div', { class: 'shot' }, el('div', { class: 'bar' }, el('i'), el('i'), el('i')), el('img', { src: d.url, alt: d.name })), el('a', { class: 'artifact', href: d.url, download: d.name, style: 'margin-top:12px' }, icon('download-simple', 'sm'), 'Download ' + d.name));
    const t = parseCsv(d.text); const wrap = el('div', {}, el('h3', { class: 'section-title' }, d.name), chartEl(t), tableEl(t));
    return wrap;
  }
};

function timelineOf(list) {
  if (!list.length) return el('p', { class: 'fine' }, 'Nothing has been delivered yet.');
  const ol = el('ol', { class: 'timeline' });
  list.slice(0, 6).forEach(x => ol.append(el('li', { dataset: { seen: String(!!x.seen) } }, el('time', {}, when(x.created_at)), el('p', {}, x.text.slice(0, 160)))));
  return ol;
}

/* ---- notifications badge ---- */
let unreadCount = 0; const countUnread = () => unreadCount;
function setBadge(n) { unreadCount = n; const c = $('#notif-count'); c.textContent = n; c.classList.toggle('hide', !n); }
export async function pollNotifications() {
  if (!state.token) { setBadge(0); return; }
  try { const n = await call('notifications'); setBadge(n.notifications.filter(x => !x.seen).length); } catch { /* quiet */ }
}
on('notifications-poll', pollNotifications);
setInterval(() => { if (!document.hidden) pollNotifications(); }, 90000);
on('auth-changed', () => { setBadge(0); if (document.body.classList.contains('bench-open')) select(current || 'do'); });

/* ---- forms ---- */
function forgetFlow() {
  sheet('Forget one saved fact', (s, close) => {
    s.append(el('p', { class: 'fine' }, 'This removes one exact fact. It does not touch your chat history or any other data. You review it before anything is removed.'));
    const key = field('Exact name of the saved fact', { hint: 'Ask Crayon “show my memory” to see the names.' });
    const go = button('Review before removing', () => busyBtn(go, async () => { try { const r = await call('action-preview', { kind: 'forget', fields: { key: key.input.value } }); close(); Approval.showReview(r); } catch (e) { msg.textContent = inCharacter(e); } }), 'btn btn-primary');
    const msg = el('p', { class: 'fine', role: 'status' }); s.append(key.wrap, msg, el('div', { class: 'row' }, go, button('Close', close, 'btn')));
  });
}
function privateRead(kind, label) {
  sheet(label, (s, close) => {
    const needs = kind !== 'calendar'; const req = needs ? field('What do you want to read?' + (['doc', 'sheet'].includes(kind) ? ' Include the file link.' : ''), { multiline: true }) : null;
    const out = el('pre', { class: 'review' }, 'Direct provider read. Not saved to your chat and not sent to the AI. Closing removes it from this view.');
    const go = button('Read from my connected account', () => busyBtn(go, async () => { try { const r = await call('private-read', { kind, fields: needs ? { request: req.input.value } : {} }); out.textContent = r.text; } catch (e) { out.textContent = inCharacter(e); } }), 'btn btn-primary');
    if (req) s.append(req.wrap); s.append(out, el('div', { class: 'row' }, go, button('Close', close, 'btn')));
  });
}
function actionForm(kind, label) {
  sheet(label, (s, close) => {
    const inputs = {};
    if (kind === 'workspace_create') inputs.request = field('Describe the Doc, Sheet or Slides you want', { multiline: true });
    else if (kind === 'form') { inputs.note = field('Test form note', { multiline: true, value: 'Controlled test only' }); }
    else if (kind === 'email') for (const k of ['to', 'cc', 'bcc', 'subject', 'body']) inputs[k] = field(k[0].toUpperCase() + k.slice(1) + (['to', 'cc', 'bcc'].includes(k) ? ' (exact addresses, comma separated)' : ''), { multiline: k === 'body' });
    else if (kind === 'calendar') inputs.request = field('Describe the event: day, time, who to invite', { multiline: true });
    else inputs.request = field('Describe the Sheet changes and include its link', { multiline: true });
    Object.values(inputs).forEach(f => s.append(f.wrap));
    const msg = el('p', { class: 'fine', role: 'status' }, 'Prepare only. You review the account, destination and full contents before anything happens.');
    const go = button('Prepare exact preview', () => busyBtn(go, async () => {
      try {
        const f = {}; for (const [k, v] of Object.entries(inputs)) f[k] = v.input.value;
        for (const k of ['to', 'cc', 'bcc']) if (k in f) f[k] = f[k].split(',').map(x => x.trim()).filter(Boolean);
        if (kind === 'form') { f.adapter = 'demo'; f.values = { name: 'TEST ONLY', note: f.note }; delete f.note; }
        const p = await call('action-preview', { kind, fields: f }); close(); emit('close-bench-small'); Approval.showReview(p);
      } catch (e) { msg.textContent = inCharacter(e) + ' Nothing changed.'; }
    }), 'btn btn-primary');
    s.append(msg, el('div', { class: 'row' }, go, button('Close', close, 'btn')));
  });
}

/* ---- rooms ---- */
function roomView(room) {
  sheet('Room: ' + room.name, (s, close) => {
    s.append(el('p', { class: 'callout warn' }, 'Shared with every current and future member. No private account context or actions. Public information only.'));
    const log = el('div', { style: 'max-height:40dvh;overflow:auto' }), msg = el('p', { class: 'fine', role: 'status' });
    async function refresh() { const r = await call('rooms/history', { room: room.id }); log.replaceChildren(...r.messages.map(m => el('div', { class: 'room-msg ' + (m.role === 'assistant' ? 'crayon' : '') }, el('b', {}, m.role === 'assistant' ? 'Crayon' : m.author_label), el('p', {}, m.text)))); log.scrollTop = log.scrollHeight; }
    const input = field('Shared message', { attrs: { maxLength: 2000 } });
    const send = button('Send to this room', () => busyBtn(send, async () => { try { await call('rooms/say', { room: room.id, text: input.input.value }); input.input.value = ''; await refresh(); } catch (e) { msg.textContent = inCharacter(e) + ' Refresh before trying again.'; } }), 'btn btn-primary');
    const leave = button('Leave', async () => { try { const r = await call('rooms/leave', { room: room.id }); msg.textContent = r.text; send.disabled = true; } catch (e) { msg.textContent = inCharacter(e); } }, 'btn btn-quiet');
    const del = button('Delete for everyone…', () => { const y = button('Yes, delete this room for every member', async () => { y.disabled = true; try { const r = await call('rooms/delete', { room: room.id, accept: true }); msg.textContent = r.text; send.disabled = true; } catch (e) { msg.textContent = inCharacter(e); } }, 'btn btn-danger'); s.append(y); del.remove(); }, 'btn btn-quiet');
    s.append(log, input.wrap, msg, el('div', { class: 'row' }, send, button('Refresh', () => refresh().catch(e => msg.textContent = inCharacter(e)), 'btn'), leave, del, button('Close', close, 'btn btn-quiet')));
    refresh().catch(e => { msg.textContent = inCharacter(e); });
  });
}
on('close-bench-small', () => { if (matchMedia('(max-width:1180px)').matches) closeBench(); });
