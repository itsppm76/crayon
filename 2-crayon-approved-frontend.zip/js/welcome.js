/* The welcome area: signed-out landing (sign in + anonymous try-it via Crayon-Web) and the signed-in greeting. */
import { $, el, icon, greeting, randomId } from './util.js';
import { state, on, emit } from './bus.js';
import { webApi } from './api.js';
import { DEMO } from './config.js';
import { mascot } from './mascot.js';
import * as Auth from './auth.js';
import * as Composer from './composer.js';

const root = $('#welcome');
const SID = randomId().slice(0, 32);

const PROMPTS = [
  ['sparkle', 'Explain something simply', 'Explain something to me simply: '],
  ['envelope', 'Help me write a message', 'Help me write a message to '],
  ['checks', 'What is on my task list?', 'my tasks'],
  ['brain', 'What do you remember about me?', 'show my memory'],
  ['alarm', 'Remind me about something', 'Remind me to '],
  ['globe', 'Research something properly', 'Research ']
];

export function render() {
  root.replaceChildren();
  if (state.token) return signedIn();
  landing();
}

function signedIn() {
  const name = (state.user?.name || '').split(' ')[0];
  root.append(
    el('div', { class: 'hello' }, mascot('idle'), el('h1', {}, `${greeting()}${name ? ', ' + name : ''}. What should I take off your plate?`)),
    el('p', { class: 'sub' }, 'Say it the way you would to a person. I will search, read, remember, remind and draft, and ask before anything that sends or changes something.'),
    el('div', { class: 'prompt-list', role: 'list' }, PROMPTS.map(([ic, label, text]) =>
      el('button', { type: 'button', role: 'listitem', onclick: () => Composer.fill(text, { go: /^(my tasks|show my memory)$/.test(text) }) }, icon(ic), label, icon('arrow-up', 'sm arrow')))));
}

function landing() {
  const auth = el('div', { class: 'auth-card' },
    el('button', { class: 'btn btn-primary btn-block', type: 'button', id: 'google-login', onclick: () => Auth.startLogin('google') }, icon('google-logo'), 'Continue with Google'),
    el('button', { class: 'btn btn-block', type: 'button', id: 'tg-login', onclick: () => Auth.startLogin('telegram') }, icon('telegram-logo'), 'Continue with Telegram'),
    el('div', { class: 'or' }, 'or use email'),
    (() => {
      const f = el('form', { class: 'field', onsubmit: e => { e.preventDefault(); Auth.emailLogin(inp.value, false); } });
      const inp = el('input', { class: 'input', type: 'email', id: 'auth-email', autocomplete: 'email', placeholder: 'you@example.com', 'aria-label': 'Email address' });
      f.append(inp, el('button', { class: 'btn btn-block', type: 'submit' }, icon('at'), 'Continue with email'), el('span', { class: 'hint' }, 'Email sign-in needs a verified address. Passwords stay with Firebase.')); return f;
    })(),
    el('p', { class: 'fine' }, 'Already use Crayon on Telegram? Sign in with Telegram to keep one account. A Google or email login you start separately makes a separate account.'));

  root.append(el('div', { class: 'landing' },
    el('div', { style: 'display:flex;flex-direction:column;gap:24px' },
      el('div', { class: 'hello' }, mascot('idle'), el('h1', {}, 'Hand it to Crayon.')),
      el('p', { class: 'sub' }, 'Crayon does the everyday digital chores for you: searches, reminders, drafts, research, files. Same account and memory on Telegram and here.'),
      auth),
    tryIt()));
}

/* Anonymous try-it. Uses Crayon-Web /api/*; any failure becomes an in-character line, never an error. */
function tryIt() {
  if (!DEMO) return el('section', { class: 'try', 'aria-labelledby': 'try-h' },
    el('h2', { id: 'try-h' }, 'A place for your everyday work'),
    mascot('idle'),
    el('p', { class: 'sub' }, 'Ask naturally. Crayon can research, remember, draft and help you keep things moving.'),
    el('p', { class: 'fine' }, 'Sign in to use your own account, history and connected services. External actions always need your exact review.'),
    el('div', { class: 'prompt-list' }, PROMPTS.slice(0, 4).map(([ic, label]) =>
      el('button', { type: 'button', onclick: () => { document.querySelector('#google-login').focus(); emit('toast', 'Choose a sign-in method to begin.'); } }, icon(ic), label, icon('arrow-up', 'sm arrow')))));

  const out = el('div', { class: 'out', 'aria-live': 'polite' }, 'Ask anything. This is the guest version: no memory, no actions, limited per hour.');
  const input = el('input', { class: 'input', placeholder: 'Ask a quick question…', 'aria-label': 'Quick question', maxLength: 500 });
  const go = el('button', { class: 'btn btn-primary', type: 'submit' }, 'Ask');
  const form = el('form', { class: 'row', onsubmit: async e => { e.preventDefault(); const q = input.value.trim(); if (!q) return; go.disabled = true; out.textContent = ''; const m = mascot('thinking'); m.style.cssText = 'width:28px;height:34px;display:inline-block;vertical-align:middle;margin-right:8px'; out.append(m, 'Thinking…'); try { await stream(q, out); } finally { go.disabled = false; } input.value = ''; } }, input, go);
  const chip = (label, fn) => el('button', { type: 'button', class: 'chip', onclick: async () => { out.textContent = 'One moment…'; try { await fn(out); } catch { sleepy(out); } } }, label);
  return el('section', { class: 'try', 'aria-labelledby': 'try-h' },
    el('h2', { id: 'try-h' }, 'Try it without signing in'), out, form,
    el('div', { class: 'row', style: 'flex-wrap:wrap' },
      chip('Weather in Mumbai', c => card(c, '/api/weather?q=Mumbai', weatherCard)),
      chip('USD to INR', c => card(c, '/api/fx?pair=USDINR', fxCard)),
      chip('Apple stock', c => card(c, '/api/stock?sym=AAPL', stockCard))),
    el('p', { class: 'fine' }, 'Guest answers come from a shared free service and may be slow to wake up.'));
}

function sleepy(out) {
  out.replaceChildren(); const m = mascot('sleepy'); m.style.cssText = 'width:40px;height:48px;float:left;margin-right:12px';
  out.append(m, 'Crayon is stretching awake — free hosting naps. Give it a few seconds and ask again, or sign in and I will keep your message in line for you.');
}

async function stream(q, out) {
  let r;
  try { r = await webApi('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: q, session_id: SID, tz: Intl.DateTimeFormat().resolvedOptions().timeZone }) }); }
  catch { return sleepy(out); }
  if (!r.ok || !r.body) return sleepy(out);
  out.replaceChildren(); const text = document.createTextNode(''); const label = el('div', { class: 'fine' }); out.append(label, text, el('span', { class: 'caret' }));
  const rd = r.body.getReader(), dec = new TextDecoder(); let buf = '', got = false;
  try {
    for (;;) {
      const { value, done } = await rd.read(); if (done) break;
      buf += dec.decode(value, { stream: true });
      let i; while ((i = buf.indexOf('\n\n')) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 2);
        if (!line.startsWith('data:')) continue; const d = line.slice(5).trim(); if (d === '[DONE]') continue;
        let j; try { j = JSON.parse(d); } catch { continue; }
        if (j.t) { got = true; label.textContent = ''; text.textContent += j.t; } else if (j.m) label.textContent = j.m; else if (j.err) { if (!got) return sleepy(out); }
      }
    }
  } catch { if (!got) return sleepy(out); }
  out.querySelector('.caret')?.remove(); if (!got) sleepy(out);
}

async function card(out, path, build) {
  const r = await webApi(path); if (!r.ok) return sleepy(out);
  const j = await r.json(); out.replaceChildren(build(j));
}
const weatherCard = j => el('div', { class: 'datacard' }, el('span', { class: 'lbl' }, j.place + ' · ' + j.cond), el('strong', {}, Math.round(j.temp) + '°C'), el('span', {}, `feels ${Math.round(j.feels)}° · humidity ${Math.round(j.humidity)}%`),
  el('small', {}, (j.days || []).map(d => `${d.date.slice(5)}: ${Math.round(d.min)}–${Math.round(d.max)}°`).join('   ') + ' · ' + j.source));
const fxCard = j => el('div', { class: 'datacard' }, el('span', { class: 'lbl' }, `${j.base} to ${j.to}`), el('strong', {}, Number(j.rate).toFixed(2)), el('small', {}, `${j.date} · ${j.source}`));
const stockCard = j => el('div', { class: 'datacard' }, el('span', { class: 'lbl' }, `${j.symbol} · ${j.name}`), el('strong', {}, `${j.price} ${j.currency}`), j.prev ? el('span', {}, `prev close ${j.prev}`) : null, el('small', {}, `Delayed · ${j.date} · ${j.source}`));

on('auth-changed', render);
on('signed-in', render);
on('thread-cleared', () => { if (state.token) $('#welcome').classList.remove('hide'); });
