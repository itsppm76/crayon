/* Composer: auto-grow input, attach, research mode, mic (speech-to-text with edit-before-send), quote reply, local queue */
import { $, el, icon, iconBtn } from './util.js';
import { state, emit, on } from './bus.js';
import * as Chat from './chat.js';
import * as Approval from './approval.js';
import { status, menu, closeMenu } from './ui.js';

const input = $('#input'), send = $('#send'), form = $('#form');
let staged = null, stagedPreview = null, quote = null;

export const MODES = [
  { id: '', label: 'Agent', hint: 'Crayon decides how to work', icon: 'compass' },
  { id: 'web', label: 'Web research', hint: 'Search and read public pages', icon: 'globe' },
  { id: 'deep', label: 'Deep research', hint: 'Longer, multi-source, cited', icon: 'books' },
  { id: 'academic', label: 'Academic', hint: 'Papers and scholarly sources', icon: 'graduation-cap' },
  { id: 'social', label: 'Social', hint: 'What people are saying', icon: 'users-three' },
  { id: 'video', label: 'Video', hint: 'Find and summarise videos', icon: 'video-camera' }
];
state.focus = '';
function setMode(m) {
  state.focus = m.id; $('#mode-label').textContent = m.label;
  $('#mode').setAttribute('aria-label', 'Research mode: ' + m.label);
  $('#mode').classList.toggle('on', !!m.id);
  $('#mode').firstElementChild.firstElementChild.setAttribute('href', 'assets/icons.svg#i-' + m.icon);
}
$('#mode').onclick = e => menu(e.currentTarget, MODES.map(m => ({ label: m.label, hint: m.hint, icon: m.icon, checked: m.id === state.focus, onclick: () => setMode(m) })), { up: true });

export function refresh() {
  const on_ = !!state.token;
  input.disabled = !on_;
  $('#attach').disabled = !on_; $('#mic').disabled = !on_; $('#mode').disabled = !on_;
  send.disabled = !on_ || (!input.value.trim() && !staged);
  input.placeholder = on_ ? 'Ask Crayon to do something…' : 'Sign in to give Crayon a task';
}
function grow() { input.style.height = 'auto'; input.style.height = Math.min(180, input.scrollHeight) + 'px'; }
input.addEventListener('input', () => { grow(); refresh(); });
input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); form.requestSubmit(); } });
form.addEventListener('submit', async e => {
  e.preventDefault();
  if (micOn) { recognition.stop(); status('Recording stopped. Check the text, then send.'); return; }
  if (staged) {
    if (Chat.isWorking()) { status('Crayon is mid-task. Send the file when it finishes.'); return; }
    const f = staged, cap = input.value.trim(), pv = stagedPreview; stagedPreview = null; clearStage(true);
    input.value = ''; grow(); refresh(); Chat.sendAttachment(f, cap, pv); return;
  }
  const text = input.value.trim(); if (!text) return;
  const q = quote; input.value = ''; grow(); clearQuote(); refresh();
  const ok = await Chat.ask(text, { quote: q });
  if (!ok) { input.value = text; grow(); refresh(); }
});

/* quote reply */
export function setQuote(text) {
  clearQuote(); quote = text;
  const chip = el('div', { class: 'stage-chip', id: 'quote-stage' }, icon('arrow-bend-up-left', 'sm'), el('span', { class: 't' }, 'Replying to: ' + text.slice(0, 160)), iconBtn('x', 'Remove reply', clearQuote, 'sm'));
  $('#quote-slot').append(chip); input.focus();
}
function clearQuote() { quote = null; $('#quote-slot').replaceChildren(); }
on('quote', setQuote);
on('thread-cleared', clearQuote);

/* attachment */
const stage = $('#attachment-stage');
function clearStage(keepPreview) {
  staged = null; if (stagedPreview && !keepPreview) URL.revokeObjectURL(stagedPreview); stagedPreview = null;
  $('#file').value = ''; stage.replaceChildren(); stage.classList.add('hide'); refresh();
}
$('#attach').onclick = () => $('#file').click();
$('#file').onchange = () => {
  const f = $('#file').files[0]; if (!f || !state.token) return;
  if (f.size > 20_000_000) { status('Files can be up to 20 MB.'); $('#file').value = ''; return; }
  clearStage(); staged = f; stage.classList.remove('hide');
  const chip = el('div', { class: 'stage-chip' });
  if (f.type.startsWith('image/')) { stagedPreview = URL.createObjectURL(f); chip.append(el('img', { src: stagedPreview, alt: 'Attachment preview' })); } else chip.append(icon('paperclip'));
  chip.append(el('span', { class: 't' }, f.name), iconBtn('x', 'Remove attachment', () => clearStage(), 'sm'));
  stage.append(chip); status('Attachment ready. Add a question or context, then send.'); refresh(); input.focus();
};
on('attach-clear', () => clearStage());

/* voice: browser speech-to-text, text stays editable until Send (same consent text as the shipped app) */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null, micOn = false;
$('#mic').onclick = () => {
  if (!state.token) return;
  if (Approval.hasActive()) { status('Cancel or edit the pending review first.'); return; }
  if (micOn) { recognition.stop(); return; }
  if (!SR) { status('This browser cannot transcribe speech. Type your request, or attach an audio file for Crayon to listen to.'); return; }
  if (!confirm('Your browser may send microphone audio to its own speech service. The text appears here for you to check, and goes to Crayon only when you press Send. Continue?')) return;
  recognition = new SR(); recognition.lang = navigator.language || 'en-IN'; recognition.interimResults = true; recognition.continuous = false;
  const initial = input.value;
  recognition.onstart = () => { micOn = true; $('#mic').setAttribute('aria-pressed', 'true'); $('#mic').setAttribute('aria-label', 'Stop recording'); status('Listening. Say your request, then stop.'); };
  recognition.onresult = ev => { let t = ''; for (const r of ev.results) t += r[0].transcript + ' '; input.value = (initial + (initial ? ' ' : '') + t.trim()).slice(0, 8000); grow(); refresh(); };
  recognition.onerror = ev => status(ev.error === 'not-allowed' ? 'Microphone permission was declined. You can type instead.' : 'Voice stopped. Check any text before sending.');
  recognition.onend = () => { micOn = false; $('#mic').setAttribute('aria-pressed', 'false'); $('#mic').setAttribute('aria-label', 'Record voice'); status('Recording stopped. Check the text, then send.'); refresh(); };
  try { recognition.start(); } catch { status('Voice could not start. Type instead.'); }
};
on('signed-out', () => { if (recognition && micOn) recognition.abort(); clearStage(); clearQuote(); input.value = ''; grow(); refresh(); });

export function fill(text, { go = false } = {}) { input.value = text; grow(); refresh(); input.focus(); if (go) form.requestSubmit(); }

/* waiting list: messages that will go in order after the current task */
on('queue-changed', list => {
  let slot = $('#queue-slot');
  if (!slot) { slot = el('div', { id: 'queue-slot' }); $('#quote-slot').after(slot); }
  slot.replaceChildren(...list.map((t, i) => el('div', { class: 'stage-chip' }, el('span', { class: 'pos queue-pos' }, '#' + (i + 1)), el('span', { class: 't' }, t), iconBtn('x', 'Remove from the waiting list', () => Chat.dropWaiting(i), 'sm'))));
});
on('working', w => { form.dataset.working = String(w); });
on('signed-in', refresh); on('auth-changed', refresh); on('restoring', refresh);
refresh();
