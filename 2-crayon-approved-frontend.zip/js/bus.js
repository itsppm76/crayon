/* Tiny event bus + shared state */
const l = new Map();
export const on = (e, f) => { (l.get(e) || l.set(e, new Set()).get(e)).add(f); return () => l.get(e).delete(f); };
export const emit = (e, d) => { (l.get(e) || []).forEach(f => { try { f(d); } catch (x) { console.error(x); } }); };
export const state = { token: '', user: null, conversation: null, conversations: [], busy: false, host: 'unknown', activity: 'idle' };
