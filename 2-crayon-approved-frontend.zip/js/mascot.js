/* Crayon mascot: an original upright wax crayon. States: idle | thinking | working | done | sleepy */
const NS = 'http://www.w3.org/2000/svg';
const MARKUP = `
<defs>
  <linearGradient id="mg-WAX" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFD84D"/><stop offset="1" stop-color="#FFB800"/></linearGradient>
</defs>
<path class="m-line" d="M6 92 C 20 88, 30 96, 42 91 S 62 90, 74 93" fill="none" stroke="#FFB800" stroke-width="3.5" stroke-linecap="round"/>
<g class="m-body">
  <path d="M23 70 H57 L47 90 Q40 95 33 90 Z" fill="#E59A00"/>
  <path d="M33 90 Q40 95 47 90 L44 84 H36 Z" fill="#B87300"/>
  <rect x="21" y="14" width="38" height="58" rx="8" fill="url(#mg-WAX)"/>
  <rect x="21" y="22" width="38" height="5" fill="#1B2133" opacity=".88"/>
  <rect x="21" y="60" width="38" height="5" fill="#1B2133" opacity=".88"/>
  <g class="m-eyes"><circle cx="32" cy="40" r="3.6" fill="#1B2133"/><circle cx="48" cy="40" r="3.6" fill="#1B2133"/><circle cx="33.2" cy="38.8" r="1.2" fill="#fff"/><circle cx="49.2" cy="38.8" r="1.2" fill="#fff"/></g>
  <g class="m-lids" fill="none" stroke="#1B2133" stroke-width="2.4" stroke-linecap="round"><path d="M28.5 41 Q32 43.5 35.5 41"/><path d="M44.5 41 Q48 43.5 51.5 41"/></g>
  <circle cx="27" cy="49" r="3" fill="#FF6B57" opacity=".55"/><circle cx="53" cy="49" r="3" fill="#FF6B57" opacity=".55"/>
  <path class="m-mouth-smile" d="M34 48 Q40 55 46 48" fill="none" stroke="#1B2133" stroke-width="2.6" stroke-linecap="round"/>
  <path class="m-mouth-flat" d="M36 51 H44" fill="none" stroke="#1B2133" stroke-width="2.6" stroke-linecap="round"/>
  <ellipse class="m-mouth-o" cx="40" cy="51" rx="3" ry="3.4" fill="#1B2133"/>
  <path class="m-check" d="M30 78 L38 85 L52 72" fill="none" stroke="#12794C" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<g class="m-spark" fill="#FFC21A"><path d="M66 18 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z"/><path d="M12 30 l1.5 3.5 3.5 1.5 -3.5 1.5 -1.5 3.5 -1.5 -3.5 -3.5 -1.5 3.5 -1.5z"/></g>
<g class="m-z" fill="#4FB3FF" font-family="Figtree,sans-serif" font-weight="800"><text x="58" y="20" font-size="13">z</text><text x="66" y="10" font-size="9">z</text></g>`;

let uid = 0;
export function mascot(state = 'idle', cls = '') {
  const svg = document.createElementNS(NS, 'svg');
  const id = 'm' + (++uid);
  svg.setAttribute('viewBox', '0 0 80 100');
  svg.setAttribute('class', 'mascot ' + cls);
  svg.setAttribute('data-state', state);
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.innerHTML = MARKUP.replace(/mg-WAX/g, 'mg-' + id);
  return svg;
}
export function setMascot(el, state) { if (el && el.dataset.state !== state) el.dataset.state = state; }
/* Replace every <span data-mascot="state"> placeholder in a subtree */
export function hydrateMascots(root = document) {
  root.querySelectorAll('[data-mascot]').forEach(p => {
    const m = mascot(p.dataset.mascot, p.className);
    if (p.id) m.id = p.id;
    p.replaceWith(m);
  });
}
