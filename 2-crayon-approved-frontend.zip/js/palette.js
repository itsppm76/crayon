/* Command palette (Ctrl/Cmd+K): every workbench panel + shortcut, keyboard-first */
import { $, el, icon } from './util.js';
import { state, emit } from './bus.js';
import * as Chat from './chat.js';
import * as Composer from './composer.js';

const CMDS = [
  ['Ask', 'New chat', 'plus', () => $('#new-chat').click(), 'N'],
  ['Ask', 'My tasks', 'checks', () => Chat.ask('my tasks')],
  ['Ask', 'Show my memory', 'brain', () => Chat.ask('show my memory')],
  ['Ask', 'My reminders', 'alarm', () => Chat.ask('my reminders')],
  ['Ask', 'Work queue', 'kanban', () => Chat.ask('/work list')],
  ['Ask', 'Computer jobs', 'monitor', () => Chat.ask('/computer status')],
  ['Ask', 'Help: what can you do?', 'question', () => Chat.ask('/help')],
  ['Open', 'Routines and check-ins', 'clock-countdown', () => emit('open-bench', { tab: 'routines' })],
  ['Open', 'Notifications', 'bell', () => emit('open-bench', { tab: 'notifications' })],
  ['Open', 'Shared rooms', 'users-three', () => emit('open-bench', { tab: 'rooms' })],
  ['Open', 'Connections (Gmail, Calendar, Docs)', 'plug', () => emit('open-bench', { tab: 'connections' })],
  ['Open', 'Web activity', 'lightning', () => emit('open-bench', { tab: 'activity' })],
  ['Open', 'Plugins and MCP', 'cube', () => emit('open-bench', { tab: 'plugins' })],
  ['Open', 'Canvas', 'chart-bar', () => emit('open-bench', { tab: 'canvas' })],
  ['Do', 'Export this chat', 'download-simple', () => $('#exportbtn').click()],
  ['Do', 'Switch light or dark', 'moon', () => $('#theme').click()],
  ['Do', 'Attach a file', 'paperclip', () => $('#attach').click()]
];
let dlg = null;
export function openPalette() {
  if (dlg) return;
  dlg = el('dialog', { 'aria-label': 'Commands' });
  const input = el('input', { placeholder: 'Type a command or a task…', 'aria-label': 'Search commands', role: 'combobox', 'aria-expanded': 'true', 'aria-controls': 'pal-list' });
  const list = el('ul', { id: 'pal-list', role: 'listbox' });
  dlg.append(el('div', { class: 'palette' }, input, list)); $('#dialogs').append(dlg);
  let items = [], sel = 0;
  const draw = () => {
    const q = input.value.trim().toLowerCase(); list.replaceChildren(); items = [];
    let group = '';
    CMDS.filter(c => !q || c[1].toLowerCase().includes(q) || c[0].toLowerCase().includes(q)).forEach(c => {
      if (c[0] !== group) { group = c[0]; list.append(el('li', { class: 'group', role: 'presentation' }, group)); }
      const b = el('button', { type: 'button', role: 'option', onclick: () => run(c) }, icon(c[2]), c[1]); if (c[4]) b.append(el('span', { class: 'hint' }, el('span', { class: 'kbd' }, c[4])));
      list.append(el('li', {}, b)); items.push(b);
    });
    if (q && state.token) { const b = el('button', { type: 'button', role: 'option', onclick: () => { close(); Chat.ask(input.value.trim()); } }, icon('paper-plane-tilt'), `Ask Crayon: “${input.value.trim()}”`); list.append(el('li', {}, b)); items.push(b); }
    sel = Math.min(sel, items.length - 1); mark();
  };
  const mark = () => items.forEach((b, i) => b.setAttribute('aria-selected', String(i === sel)));
  const close = () => { dlg.close(); dlg.remove(); dlg = null; };
  const run = c => { close(); c[3](); };
  input.addEventListener('input', () => { sel = 0; draw(); });
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { sel = (sel + 1) % items.length; mark(); items[sel].scrollIntoView({ block: 'nearest' }); e.preventDefault(); }
    if (e.key === 'ArrowUp') { sel = (sel - 1 + items.length) % items.length; mark(); items[sel].scrollIntoView({ block: 'nearest' }); e.preventDefault(); }
    if (e.key === 'Enter') { items[sel]?.click(); e.preventDefault(); }
  });
  dlg.addEventListener('cancel', e => { e.preventDefault(); close(); });
  dlg.addEventListener('click', e => { if (e.target === dlg) close(); });
  draw(); dlg.showModal(); input.focus();
}
$('#palette-open').onclick = openPalette;
document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openPalette(); } });
