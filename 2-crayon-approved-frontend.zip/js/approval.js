/* Approval cards. Contract is unchanged: action-preview -> action-confirm {review_id, hash, decision}.
   One use, hash-bound, 10 minute expiry, never an automatic retry. */
import { el, icon, fmtTime } from './util.js';
import { call, inCharacter } from './api.js';
import { STATES } from './progress.js';
import { addAi, log, scrollEnd } from './thread.js';
import { mascot } from './mascot.js';
import { emit } from './bus.js';
import { sheet, field, button } from './ui.js';

export const LABELS = { email: 'Send exactly this', calendar: 'Create exactly this', sheet: 'Update exactly this', workspace_create: 'Create exactly this', form: 'Submit these fields once', forget: 'Forget exactly this fact' };
const TITLES = { email: 'Review email', calendar: 'Review calendar event', sheet: 'Review Sheet update', workspace_create: 'Review Google file', form: 'Review form submission', forget: 'Review saved fact removal' };
const STAMPS = { email: 'SENT', calendar: 'ADDED', sheet: 'UPDATED', workspace_create: 'CREATED', form: 'SUBMITTED', forget: 'FORGOTTEN' };
export let active = null;
export const hasActive = () => !!active;

export function dispose() { if (active) { active.dispose(); active = null; } document.body.classList.remove('review-open'); }

export function showReview(p, { onClarify } = {}) {
  if (p.kind === 'clarification') { addAi(p.text); emit('status', 'Waiting for one missing detail. Nothing changed.'); onClarify?.(p); return null; }
  emit('close-menus');
  if (active) { active.dispose(); active.row.remove(); active = null; }

  const state = el('span', { class: 'state', role: 'status' }, icon('hourglass', 'sm'), 'Awaiting your review');
  const timer = el('span', { class: 'timer', 'aria-hidden': 'true' });
  const note = el('p', { class: 'note' }, 'Nothing has been sent or changed. Check the account, destination and full contents below. Closing this view is not approval.');
  const pre = el('pre', { class: 'review', tabIndex: 0 }, p.text);
  const card = el('section', { class: 'approval', 'aria-label': 'Review exact action' },
    el('header', {}, icon('shield-check', 'lg'), el('h2', {}, TITLES[p.kind] || 'Review exact action'), timer, state),
    el('span', { class: 'stamp', 'aria-hidden': 'true' }, STAMPS[p.kind] || 'DONE'),
    note, pre);
  if (p.kind === 'email' && p.html) card.append(el('iframe', { sandbox: '', title: 'Exact HTML email preview', srcdoc: p.html }));
  const footer = el('footer'); card.append(footer);

  const row = el('div', { class: 'msg ai', dataset: { privateReview: 'true' } }, mascot('idle', 'av'), el('div', { class: 'body' }, card));
  log.append(row); document.body.classList.add('review-open'); scrollEnd(true); requestAnimationFrame(() => { const tall = card.offsetHeight > innerHeight - 140; (tall ? card.querySelector('footer') || card : card).scrollIntoView({ block: tall ? 'end' : 'start', behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth' }); });

  let claimed = false;
  const expires = Date.now() + Math.max(0, Number(p.expires_in) || 600) * 1000;
  const disableAll = () => footer.querySelectorAll('button').forEach(b => b.disabled = true);
  const clock = setInterval(() => { const left = Math.max(0, Math.round((expires - Date.now()) / 1000)); timer.textContent = claimed ? '' : 'expires in ' + fmtTime(left); if (left <= 0) expire(); }, 1000);
  timer.textContent = 'expires in ' + fmtTime(Math.max(0, Math.round((expires - Date.now()) / 1000)));
  const setState = (txt, ic) => { state.replaceChildren(icon(ic, 'sm'), txt); };
  function settle(outcome, text, stateText, ic) {
    claimed = true; clearInterval(clock); card.dataset.outcome = outcome; setState(stateText, ic);
    if (text != null) pre.textContent = text; card.querySelector('iframe')?.remove(); footer.remove(); timer.remove();
    if (active?.card === card) active = null;
    document.body.classList.remove('review-open');
    emit('review-settled', outcome);
  }
  function expire() { if (claimed) return; settle('expired', null, 'Review expired. Ask again for a fresh preview.', 'clock-countdown'); note.textContent = 'Nothing changed.'; emit('status', 'Review expired. Nothing changed.'); }
  active = { card, row, dispose: () => { claimed = true; clearInterval(clock); disableAll(); } };

  const confirm = button(LABELS[p.kind] || 'Confirm exactly this', () => decide('confirm'), 'btn btn-primary');
  const cancel = button('Cancel', () => decide('cancel'), 'btn');
  footer.append(confirm, cancel);
  async function decide(decision) {
    if (claimed) return;
    if (Date.now() >= expires) { expire(); return; }
    claimed = true; disableAll(); clearInterval(clock);
    setState(decision === 'confirm' ? 'Verifying the result' : 'Cancelling', 'hourglass'); confirm.classList.toggle('loading', decision === 'confirm');
    try {
      const r = await call('action-confirm', { review_id: p.review_id, hash: p.hash, decision });
      const outcome = r.state || 'unknown';
      settle(outcome, r.text, STATES[outcome] || STATES.unknown, outcome === 'done' ? 'check-circle' : 'warning');
      note.textContent = 'No automatic retry. This receipt does not imply email delivery or visual file approval.';
      emit('status', outcome === 'done' ? 'Provider result confirmed.' : outcome === 'cancelled' ? 'Cancelled. Nothing was done.' : 'Outcome unconfirmed. Check the destination before asking again.');
    } catch (e) {
      settle('unknown', inCharacter(e) + ' I could not confirm whether this went through, so I will not try again on my own. Check the destination before another request.', 'Outcome unconfirmed', 'warning');
      emit('status', 'Outcome unconfirmed. The action was not resent.');
    }
  }
  if (p.review_fields) {
    const edit = button('Edit and prepare a new review', () => {
      if (claimed) return;
      sheet('Edit exact fields', (s, close) => {
        s.append(el('p', { class: 'fine' }, 'Changing fields creates a new preview and a new review ticket. It never changes this review or sends it.'));
        const f = field('Exact fields (JSON)', { value: JSON.stringify(p.review_fields, null, 2), multiline: true, attrs: { rows: 12, spellcheck: 'false' } });
        const msg = el('p', { class: 'fine', role: 'status' });
        const go = button('Prepare new preview', async () => {
          if (claimed || Date.now() >= expires) { expire(); close(); return; }
          go.disabled = true;
          try {
            const fields = JSON.parse(f.input.value);
            const next = await call('action-preview', { kind: p.kind, fields });
            if (next.kind === 'clarification') { msg.textContent = next.text; go.disabled = false; return; }
            claimed = true; clearInterval(clock); disableAll(); close(); showReview(next);
          } catch (e) { msg.textContent = (e instanceof SyntaxError ? 'That is not valid JSON.' : inCharacter(e)) + ' Your original review is still open.'; go.disabled = false; }
        }, 'btn btn-primary');
        s.append(f.wrap, msg, el('div', { class: 'row' }, go, button('Close', close, 'btn')));
      });
    }, 'btn btn-quiet', 'pencil-simple');
    footer.append(edit);
  }
  return card;
}

/* MCP tool call review (inline card, same one-use rule) */
export function mcpReview(p) {
  const pre = el('pre', { class: 'review' }, p.text);
  const card = el('section', { class: 'approval', 'aria-label': 'Review MCP tool call' }, el('header', {}, icon('plug', 'lg'), el('h2', {}, 'Review connector call'), el('span', { class: 'state' }, 'Awaiting your review')), el('span', { class: 'stamp', 'aria-hidden': 'true' }, 'DONE'), pre);
  const footer = el('footer'); card.append(footer);
  const yes = button('Call exactly this once', () => go('confirm'), 'btn btn-primary'); const no = button('Cancel', () => go('cancel'), 'btn');
  footer.append(yes, no);
  async function go(decision) {
    footer.querySelectorAll('button').forEach(b => b.disabled = true);
    try { const r = await call('mcp', { action: 'confirm', review_id: p.review_id, decision }); pre.textContent = r.text + (r.untrusted ? '\nExternal server result, not independently verified.' : ''); card.dataset.outcome = decision === 'confirm' ? 'done' : 'cancelled'; card.querySelector('.state').textContent = decision === 'confirm' ? 'Done' : 'Cancelled'; footer.remove(); }
    catch (e) { pre.textContent = inCharacter(e) + ' Not retried.'; card.dataset.outcome = 'unknown'; card.querySelector('.state').textContent = 'Outcome unconfirmed'; footer.remove(); }
  }
  log.append(el('div', { class: 'msg ai', dataset: { privateReview: 'true' } }, mascot('idle', 'av'), el('div', { class: 'body' }, card))); scrollEnd(true);
}
