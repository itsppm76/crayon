/* Chat engine. Same contract as the shipped app: intent -> chat (202 + request_id) -> poll result.
   Added behaviour (safe because /web/chat is idempotent on request_id): when the host is asleep or busy,
   the SAME request_id is re-submitted with back-off, so a nap never duplicates work and never shows an error. */
import { $, el, icon, randomId, sleep } from './util.js';
import { state, emit, on } from './bus.js';
import { call, transient, isBusy, isDailyCap, inCharacter } from './api.js';
import { DEMO, POLL_MS, POLL_MAX } from './config.js';
import { SETTLED, steps } from './progress.js';
import { addUser, addAi, createRun, workStrip, busyNote, renderItem, scrollEnd, log } from './thread.js';
import { mascot, setMascot } from './mascot.js';
import * as Approval from './approval.js';
import { sheet, field, button, status } from './ui.js';

const waiting = [];           // messages queued locally, not yet in the thread
let working = false;
let pendingAction = null;     // multi-turn preview (missing detail)
let pendingCompose = false;
export const isWorking = () => working;
export const queueLength = () => waiting.length;

function presence(stateName, line) { emit('presence', { state: stateName, line }); }

/* ---------- entry ---------- */
export async function ask(text, opts = {}) {
  text = (text || '').trim();
  if (!state.token || !text) return false;
  if (Approval.hasActive()) { status('Cancel or edit the pending review before a new request. Nothing was sent.'); return false; }

  // multi-turn preview continuation never queues; it is a quick local exchange
  if (pendingAction && pendingAction.until < Date.now()) pendingAction = null;
  if (pendingAction || pendingCompose) return foreground(text, opts);

  // non-chat routes need a live turn; chat messages may queue behind one that is working
  if (working) {
    waiting.push({ text, opts, id: randomId() });
    emit('queue-changed', waiting.map(w => w.text));
    status(`Queued. ${waiting.length} message${waiting.length === 1 ? '' : 's'} waiting; they go in order.`);
    return true;
  }
  return foreground(text, opts);
}
export function dropWaiting(i) { waiting.splice(i, 1); emit('queue-changed', waiting.map(w => w.text)); }

async function foreground(text, opts) {
  working = true; emit('working', true);
  try { await handle(text, opts); }
  finally {
    working = false; emit('working', false);
    const next = waiting.shift(); emit('queue-changed', waiting.map(w => w.text));
    if (next) ask(next.text, next.opts);
  }
  return true;
}

async function handle(text, opts) {
  addUser(text, { quote: opts.quote });
  if (pendingAction) {
    if (/^(cancel|stop|never mind)$/i.test(text)) { pendingAction = null; addAi('Preparation cancelled. Nothing changed.'); return; }
    pendingAction.request += '\nAdditional user detail: ' + text;
    try {
      const p = await call('action-preview', { kind: pendingAction.kind, fields: { request: pendingAction.request } });
      if (p.kind !== 'clarification') pendingAction = null;
      Approval.showReview(p);
    } catch (e) { addAi(inCharacter(e) + ' Nothing changed.'); }
    return;
  }

  let intent;
  try { intent = pendingCompose ? { route: 'email', args: {} } : await call('intent', { message: text }); }
  catch (e) {
    if (transient(e) || isBusy(e)) intent = { route: 'chat', args: {}, ticket: undefined };
    else { addAi('I could not read that safely just now. Nothing changed. Please ask again.'); return; }
  }
  if (intent.route === 'clarify') { addAi(intent.args.question); return; }
  if (intent.route === 'export') { emit('export', intent.args.format || 'ask'); return; }
  if (intent.route === 'private_read') {
    try { const r = await call('private-read', { kind: intent.args.kind, fields: { request: text } }); showPrivate(r.text); status('Shown separately. It was not sent to the chat model.'); }
    catch (e) { addAi(inCharacter(e)); }
    return;
  }
  if (intent.route === 'preview') {
    try {
      if (['form', 'forget'].includes(intent.args.kind)) { addAi(intent.args.kind === 'forget' ? 'Open the Memory shortcut in the workbench and pick the exact fact. Nothing was removed.' : 'Open Connections to review the supported free form and its exact fields. Nothing was submitted.'); return; }
      const p = await call('action-preview', { kind: intent.args.kind, fields: { request: text } });
      if (p.kind === 'clarification') pendingAction = { kind: intent.args.kind, request: text, until: Date.now() + 600000 };
      Approval.showReview(p); status('Preview only. Nothing external was done.');
    } catch (e) { addAi(inCharacter(e) + ' Nothing changed.'); }
    return;
  }
  if (intent.route === 'mcp_connect') { emit('open-bench', { tab: 'plugins', prefill: text.match(/https:\/\/[^\s]+/)?.[0] || '' }); status('Review the server disclosure before connecting.'); return; }
  if (pendingCompose || intent.route === 'email') {
    try {
      const c = await call('connections');
      if (!c.google) { pendingCompose = false; addAi('Connect Google under Connections first, then I will prepare the exact email for your review. Nothing was sent.'); return; }
      const p = await call('compose-preview', { message: text });
      pendingCompose = p.kind === 'clarification' && !String(p.text).includes('cancelled');
      Approval.showReview(p); status('Draft ready for exact review. Nothing was sent.');
    } catch (e) { pendingCompose = false; addAi(inCharacter(e) + ' Nothing was sent.'); }
    return;
  }

  const id = opts.id || randomId();
  const body = { message: text, request_id: id, intent_ticket: intent.ticket, research_focus: state.focus || '', ...(state.conversation ? { conversation_id: state.conversation } : {}), ...(opts.quote ? { reply_to: { text: opts.quote } } : {}) };
  if (!body.intent_ticket) delete body.intent_ticket;
  await runRequest('chat', body, id);
}

export async function sendAttachment(file, caption, previewUrl) {
  if (!state.token || working) return;
  working = true; emit('working', true);
  try {
    const id = randomId();
    const { bubble } = addUser(caption || '');
    bubble.append(el('div', { class: 'sent-attachment' }, icon('paperclip', 'sm'), file.name));
    if (previewUrl) bubble.append(el('img', { src: previewUrl, alt: file.name, class: 'artifact-image' }));
    const data = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = () => rej(new Error('File read failed.')); r.readAsDataURL(file); });
    await runRequest('upload', { data, mime: file.type || 'application/octet-stream', name: file.name, caption, request_id: id, ...(state.conversation ? { conversation_id: state.conversation } : {}) }, id);
  } catch (e) { addAi(inCharacter(e) + ' If processing started, check Web activity before sending again.'); }
  finally { working = false; emit('working', false); const next = waiting.shift(); emit('queue-changed', waiting.map(w => w.text)); if (next) ask(next.text, next.opts); }
}

/* ---------- submit + poll with in-character waiting ---------- */
async function runRequest(path, body, id) {
  const run = createRun(); let busy = null;
  presence('working', 'Starting your request');
  const rest = () => { if (busy) { busy.remove(); busy = null; setMascot(run.face, 'working'); } };
  const nap = (title, text) => { if (!busy) busy = busyNote({ title, text }); else busy.set(title, text); setMascot(run.face, 'thinking'); presence('sleepy', 'Waking up'); };

  // 1) submit. Re-submitting the same request_id is idempotent server-side, so retry is safe.
  let attempt = 0; let accepted = false;
  while (!accepted) {
    try { await call(path, body); accepted = true; }
    catch (e) {
      if (isDailyCap(e)) { return finishSoft(run, busy, 'cancelled', inCharacter(e)); }
      if (isBusy(e) || transient(e)) {
        attempt++;
        if (attempt > (DEMO ? 14 : 0)) { return stuck(run, busy, id, path, body); }
        const wait = Math.min(15000, 2500 + attempt * 1500);
        nap(isBusy(e) ? 'Crayon has its hands full' : 'Crayon is waking up', isBusy(e)
          ? 'Your message is in line. I will resend it by itself; the same request is never run twice.'
          : 'Free hosting naps when it is quiet and takes about a minute to wake. Your message is safe and will go through on its own.');
        await sleep(wait); continue;
      }
      if (DEMO && /intent/i.test(e.message) && body.intent_ticket) { try { const i = await call('intent', { message: body.message }); body.intent_ticket = i.ticket; continue; } catch { delete body.intent_ticket; continue; } }
      return finishSoft(run, busy, 'blocked', inCharacter(e) + ' Nothing was run.');
    }
  }
  rest();
  await poll(run, id, () => busy, v => { busy = v; }, nap, rest);
}

async function poll(run, id, getBusy, setBusy, nap, rest) {
  let failures = 0;
  for (let n = 0; n < POLL_MAX; n++) {
    await sleep(failures ? Math.min(10000, POLL_MS * (failures + 1)) : POLL_MS);
    if (!state.token) { run.remove(); return; }
    let r;
    try { r = await call('result?id=' + encodeURIComponent(id)); if (failures) { failures = 0; rest(); } }
    catch (e) {
      if (e.httpStatus === 401) { run.remove(); return; }
      failures++;
      nap('Crayon is catching its breath', 'The connection dropped. I am checking on the same request; nothing is being sent again.');
      if (failures >= 12) return stuck(run, getBusy(), id, null, null);
      continue;
    }
    status(r.state === 'running' ? 'Working on your request' : r.state === 'queued' ? 'Waiting for a free slot' : '');
    const ev = r.progress || [];
    if (!SETTLED.includes(r.state)) {
      run.update(ev, r.state);
      const live = steps(ev).filter(s => s.state === 'running').pop();
      presence('working', live ? live.label : 'Working');
      if (r.draft && r.state === 'running') run.setDraft('Draft, being checked before I finalize:\n' + r.draft);
      continue;
    }
    // settled
    const outcome = run.settle(r.state, ev);
    presence('idle', 'Ready when you are');
    (r.items || []).forEach(x => renderItem(x, { mcpReview: Approval.mcpReview }));
    if (!(r.items || []).length) addAi('I did not get a confirmed result back. Check Web activity before asking again.');
    workStrip(r.state, outcome);
    setMascot(run.face, r.state === 'done' ? 'done' : 'idle');
    emit('request-settled', r.state);
    return;
  }
  stuck(run, getBusy(), id, null, null);
}

function finishSoft(run, busy, st, text) {
  busy?.remove(); run.settle(st, []); addAi(text); workStrip(st, {}); presence('idle', 'Ready when you are');
}

/* Not resolved yet: stay calm, offer a safe re-check of the SAME request */
function stuck(run, busy, id, path, body) {
  busy?.remove();
  run.settle('unknown', []);
  const wrap = addAi('I could not confirm this request yet. Check its original status before sending anything again.', { plain: true });
  const again = button('Check on it again', async () => {
    again.disabled = true;
    again.closest('.msg').remove();
    const r2 = createRun();
    try { if (DEMO && path && body) await call(path, body).catch(e => { if (!(isBusy(e) || transient(e))) throw e; }); } catch { /* handled by poll */ }
    await poll(r2, id, () => null, () => {}, () => {}, () => {});
  }, 'btn btn-sm', 'arrow-clockwise');
  wrap.wrap.append(again);
  presence('idle', 'Ready when you are');
  workStrip('unknown', {});
}

function showPrivate(text) {
  sheet('Private account result', (s, close) => {
    s.append(el('pre', { class: 'review' }, text), el('p', { class: 'fine' }, 'Direct provider read. Not saved to chat history and not sent to the AI. Closing removes it from this view.'), el('div', { class: 'row' }, button('Close', close, 'btn')));
  });
}

export function resetPending() { pendingAction = null; pendingCompose = false; waiting.length = 0; emit('queue-changed', []); }
on('signed-out', resetPending);
