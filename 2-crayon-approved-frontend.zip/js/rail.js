/* Roster rail: Crayon's presence, conversations (auto-titled), workbench links, account + theme */
import { $, $$, el, icon } from './util.js';
import { state, emit, on } from './bus.js';
import { call, inCharacter } from './api.js';
import { THEME_KEY } from './config.js';
import { setMascot } from './mascot.js';
import { menu, status, toast } from './ui.js';
import { clearThread } from './thread.js';
import { loadHistory, resetHistoryPaging } from './session.js';
import * as Chat from './chat.js';
import * as Auth from './auth.js';

const body = document.body;
export const openRail = () => body.classList.add('rail-open');
export const closeRail = () => body.classList.remove('rail-open');
$('#rail-open').onclick = () => matchMedia('(max-width:860px)').matches ? openRail() : body.classList.toggle('rail-collapsed');
$('#rail-close').onclick = closeRail; $('#scrim').onclick = () => { closeRail(); emit('close-bench'); };

/* theme */
function setTheme(t) {
  document.documentElement.dataset.theme = t;
  try { localStorage.setItem(THEME_KEY, t); } catch { /* storage may be blocked */ }
  const b = $('#theme'); b.setAttribute('aria-label', t === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
  b.firstElementChild.firstElementChild.setAttribute('href', 'assets/icons.svg#i-' + (t === 'dark' ? 'sun' : 'moon'));
}
const sysDark = () => matchMedia('(prefers-color-scheme: dark)').matches;
setTheme(document.documentElement.dataset.theme || (sysDark() ? 'dark' : 'light'));
$('#theme').onclick = () => setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');

/* presence */
const dot = $('#presence-dot'), line = $('#presence-line'), pm = $('#presence-mascot');
function setPresence(s, text) {
  const map = { working: ['working', 'working'], idle: ['live', 'idle'], sleepy: ['sleepy', 'sleepy'], off: ['off', 'sleepy'] };
  const [dotS, mascotS] = map[s] || map.idle;
  dot.dataset.s = dotS; setMascot(pm, mascotS); line.textContent = text; state.activity = s;
}
on('presence', ({ state: s, line: l }) => setPresence(s, l));
on('host', h => { if (!state.token) return; if (h === 'sleepy' && state.activity !== 'working') setPresence('sleepy', 'Waking up, one moment'); else if (h === 'awake' && state.activity === 'sleepy') setPresence('idle', 'Ready when you are'); });
on('working', w => { if (!w && state.token) setPresence('idle', 'Ready when you are'); });

/* identity + auth state */
function paintAuth() {
  const on_ = !!state.token;
  body.dataset.auth = on_ ? 'in' : 'out';
  $('#identity').textContent = on_ ? (state.user?.name || 'Crayon user') : 'Signed out';
  $('#identity-sub').textContent = on_ ? 'Web and Telegram, one account' : 'Guest';
  $('#avatar').textContent = on_ ? ((state.user?.name || 'C').trim()[0] || 'C').toUpperCase() : '?';
  if (!on_) setPresence('off', 'Sign in to wake me up');
  else setPresence('idle', 'Ready when you are');
  $('#title').textContent = on_ ? 'Crayon' : 'Crayon';
  renderConversations();
}
on('signed-in', async () => { paintAuth(); resetHistoryPaging(); await refreshConversations(); try { await loadHistory(false); } catch { status('Signed in. History is still waking up and will appear shortly.'); } emit('notifications-poll'); });
on('auth-changed', paintAuth);
on('restoring', () => { $('#identity').textContent = state.token ? 'Reconnecting…' : 'Signed out'; });

/* conversations */
export async function refreshConversations() {
  if (!state.token) return;
  try { const j = await call('conversations'); state.conversations = j.conversations || []; } catch { /* keep the last list */ }
  renderConversations();
}
function renderConversations() {
  const list = $('#convo-list'); list.replaceChildren();
  if (!state.token) { list.append(el('p', { class: 'fine', style: 'padding:4px 12px' }, 'Sign in to see your chats. They stay private to your account.')); return; }
  const mk = (id, title, ic) => el('button', { class: 'convo', type: 'button', 'aria-current': String((state.conversation ?? null) === id), onclick: () => openConversation(id, title) }, icon(ic, 'sm'), el('span', { class: 't' }, title));
  list.append(mk(null, 'Main chat (shared with Telegram)', 'chat-circle'));
  state.conversations.forEach(c => list.append(mk(c.id, c.title, 'chat-circle')));
  if (!state.conversations.length) list.append(el('p', { class: 'fine', style: 'padding:4px 12px' }, 'New chats get a title automatically after your first message.'));
}
async function openConversation(id, title) {
  if (Chat.isWorking()) { toast('Crayon is mid-task. Switch chats when it finishes.'); return; }
  state.conversation = id; resetHistoryPaging(); $('#title').textContent = id ? title : 'Crayon';
  closeRail(); renderConversations();
  try { await loadHistory(false); status(title || ''); } catch (e) { clearThread(); status('That chat is still waking up. Try again in a moment.'); }
}
$('#new-chat').onclick = async () => {
  if (!state.token) { status('Sign in first to start a chat.'); return; }
  if (Chat.isWorking()) { toast('Crayon is mid-task. Start a new chat when it finishes.'); return; }
  try { const c = await call('conversation-create', { title: 'New chat' }); state.conversation = c.id; $('#title').textContent = c.title; clearThread(); resetHistoryPaging(); await refreshConversations(); closeRail(); status('New chat. It has its own history and shares your saved facts.'); $('#input').focus(); }
  catch (e) { toast(inCharacter(e)); }
};

/* account menu */
$('#account').onclick = e => {
  const on_ = !!state.token;
  menu(e.currentTarget, on_ ? [
    { label: 'Link Google login', icon: 'google-logo', onclick: () => Auth.startLink() },
    { label: 'Link email login', icon: 'at', onclick: () => { const v = prompt('Email address to link'); if (v) Auth.emailLogin(v, true); } },
    { label: 'Link Telegram (review merge)', icon: 'telegram-logo', hint: 'Consolidation is currently off', onclick: () => Auth.startMerge() },
    { label: 'Clear this view', icon: 'trash', hint: 'Saved history and memory are unchanged', onclick: () => { clearThread(); status('View cleared only. Saved history and memory are unchanged.'); } },
    { label: 'Log out', icon: 'sign-out', onclick: async () => { try { await call('logout', {}); } catch { /* the token is dropped locally regardless */ } emit('signed-out'); status('Logged out. Stored memory and history were not deleted.'); } }
  ] : [{ label: 'Sign in', icon: 'sign-out', onclick: () => $('#google-login')?.focus() }], { align: 'right', up: true });
};
paintAuth();
