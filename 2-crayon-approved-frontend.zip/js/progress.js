/* Port of CrayonUX (ux.js): states + de-duplicated recorded work events */
export const STATES = { queued: 'Waiting for a slot', running: 'Working', awaiting_review: 'Awaiting your review', verifying: 'Verifying', done: 'Work complete', blocked: 'Work stopped', expired: 'Review expired', unknown: 'Outcome unconfirmed', cancelled: 'Cancelled' };
export const SETTLED = ['done', 'blocked', 'unknown', 'cancelled', 'expired'];
export function steps(events) {
  const map = new Map(); let legacy = 0;
  for (const e of events || []) {
    if (!e || typeof e.label !== 'string' || !Object.hasOwn(STATES, e.state)) continue;
    const id = e.id || ('legacy:' + e.label + ':' + (e.state === 'running' ? ++legacy : legacy));
    const seq = Number.isInteger(e.seq) ? e.seq : legacy;
    const old = map.get(id); if (old && old.seq > seq) continue;
    map.set(id, { id, seq, label: e.label, state: e.state });
  }
  return [...map.values()].sort((a, b) => a.seq - b.seq).slice(-8);
}
