/* Session lifecycle: restore, expiry timer, history sync. Storage keys and 7-day sessions are unchanged. */
import { state, emit, on } from './bus.js';
import { call, saveSession, dropSession, readSession, transient } from './api.js';
import { SESSION_KEY } from './config.js';
import { clearThread, renderHistory, scrollEnd } from './thread.js';
import { status } from './ui.js';
import { $ } from './util.js';
import * as Approval from './approval.js';
import * as Chat from './chat.js';

let expiryTimer, restoreTimer, restoreAttempts = 0, historyBefore = null, historyPaged = false, lastKey = '';

export function applySession(j) {
  state.token = j.token; state.user = j.user;
  const exp = Date.now() + j.expires_in * 1000;
  saveSession(j.token, exp); armExpiry(exp);
  emit('signed-in', j.user);
}
function armExpiry(exp) { clearTimeout(expiryTimer); expiryTimer = setTimeout(() => { emit('signed-out'); status('Your session ended. Sign in again.'); }, Math.max(0, exp - Date.now())); }

on('signed-out', () => {
  dropSession(); state.token = ''; state.user = null; state.conversation = null; state.conversations = [];
  clearTimeout(expiryTimer); clearTimeout(restoreTimer); Approval.dispose(); clearThread(); lastKey = ''; historyBefore = null; historyPaged = false;
  $('#older').classList.add('hide'); emit('auth-changed');
});
window.addEventListener('storage', e => { if (e.key === SESSION_KEY && !e.newValue && state.token) { emit('signed-out'); status('Signed out in another tab.'); } });

export async function loadHistory(older = false, passive = false) {
  if (!state.token) return;
  const session = state.token;
  const h = await call(state.conversation ? 'conversation-history?id=' + encodeURIComponent(state.conversation) : 'history' + (older && historyBefore ? '?before=' + encodeURIComponent(historyBefore) : ''));
  if (state.token !== session || (passive && (Chat.isWorking() || historyPaged || Approval.hasActive() || document.querySelector('dialog[open]')))) return;
  const key = h.messages.map(m => m.id).join(',');
  if (passive && key === lastKey) return; lastKey = key;
  const log = $('#log'); const prev = older ? [...log.childNodes] : [];
  if (older) log.replaceChildren(); else clearThread();
  h.messages.forEach(renderHistory); prev.forEach(x => log.append(x));
  historyBefore = h.before; $('#older').classList.toggle('hide', !h.has_more);
  if (older) { historyPaged = true; $('#scroll').scrollTop = 0; } else scrollEnd(true);
  emit('history-loaded', h.messages.length);
}
export function resetHistoryPaging() { historyBefore = null; historyPaged = false; lastKey = ''; }
$('#older').onclick = () => loadHistory(true).catch(() => status('Earlier messages could not load yet. Try again in a moment.'));

setInterval(() => { if (state.token && !Chat.isWorking() && !Approval.hasActive() && !historyPaged && !document.hidden) loadHistory(false, true).catch(() => {}); }, 30000);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) return;
  if (state.token && !Chat.isWorking() && !Approval.hasActive() && !historyPaged) loadHistory(false, true).catch(() => {});
  if (!state.token && readSession()) { restoreAttempts = 0; restore(); }
});

export async function restore() {
  clearTimeout(restoreTimer);
  const saved = readSession();
  if (!saved || typeof saved.token !== 'string' || !/^[A-Za-z0-9_-]{43}$/.test(saved.token) || typeof saved.expires !== 'number' || saved.expires <= Date.now()) { dropSession(); return false; }
  state.token = saved.token; emit('restoring');
  try {
    const user = await call('me');
    const exp = Math.min(saved.expires, user.expires_at * 1000);
    if (!Number.isFinite(exp) || exp <= Date.now()) { emit('signed-out'); return false; }
    saveSession(state.token, exp); armExpiry(exp); state.user = user; restoreAttempts = 0;
    emit('signed-in', user);
    return true;
  } catch (e) {
    if (e.httpStatus === 401) { emit('signed-out'); status('Your session ended or was revoked. Sign in again.'); return true; }
    state.token = ''; emit('restoring');
    if (++restoreAttempts < 12) { status('Your sign-in is saved. Crayon’s host is waking up, so I will keep trying.'); restoreTimer = setTimeout(restore, Math.min(15000, 2500 * restoreAttempts)); }
    else status('Your sign-in is saved. Come back to this tab or reload to reconnect.');
    return true;
  }
}
