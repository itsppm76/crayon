/* DEMO / TEST backend. Active only with ?demo=… in the URL. Never ships to users unless they add that parameter.
   Replaces window.fetch for the two Crayon hosts with deterministic fixtures. Everything shown is labelled "Demo data". */
import { API, WEB_API, SESSION_KEY, DEMO } from './config.js';

const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json' } });
const now = Date.now();
const iso = ms => new Date(ms).toISOString();
const reqs = new Map(); let hits = 0;
const mode = DEMO; // 1 | out | busy | hold | approve

if (mode !== 'out') {
  try { localStorage.setItem(SESSION_KEY, JSON.stringify({ token: 'D'.repeat(43), expires: Date.now() + 6e8 })); } catch { /* storage blocked */ }
}

function pngB64(label) {
  const c = document.createElement('canvas'); c.width = 960; c.height = 600; const x = c.getContext('2d');
  x.fillStyle = '#f4f6fa'; x.fillRect(0, 0, 960, 600); x.fillStyle = '#fff'; x.fillRect(40, 70, 880, 490);
  x.fillStyle = '#1b2133'; x.font = '700 34px sans-serif'; x.fillText(label, 70, 130);
  x.fillStyle = '#ffc21a'; x.fillRect(70, 160, 220, 14);
  x.fillStyle = '#d6dce7'; for (let i = 0; i < 7; i++) x.fillRect(70, 215 + i * 44, 520 + (i % 3) * 90, 20);
  x.fillStyle = '#1b2133'; x.fillRect(660, 215, 220, 40); x.fillStyle = '#fff'; x.font = '600 20px sans-serif'; x.fillText('Add to cart', 700, 242);
  return c.toDataURL('image/png').split(',')[1];
}
const csvB64 = () => btoa('City,Price (INR),Rating\nMumbai,18999,4.4\nDelhi,17499,4.3\nPune,18250,4.5\nChennai,19100,4.2\nKolkata,17999,4.1\nBhubaneswar,18499,4.6\n');

const ANSWER = `Three phones stand out under ₹20,000 right now:

• Poco X7 5G — about ₹18,999. Best screen and battery life at this price.
• Realme Narzo 80 Pro — about ₹17,499. Fast charging, a little heavier.
• Samsung Galaxy M36 — about ₹18,250. Six years of updates promised.

If you mostly take photos, pick the Samsung. If you game, pick the Poco. Prices move weekly, so check the live listing before you buy.

Source: https://www.gsmarena.com/poco_x7_5g-review.php
Source: https://www.91mobiles.com/best-mobile-phones-under-20000
Source: https://www.smartprix.com/mobiles/samsung-galaxy-m36-5g`;

const EVENTS = [
  ['s1', 'Request accepted'], ['s2', 'Searching public sources'], ['s3', 'Reading a public page'], ['s4', 'Checking sources'], ['s5', 'Running a calculation']
];
function progressAt(t, hold) {
  const out = []; let seq = 0;
  EVENTS.forEach(([id, label], i) => {
    const start = i * 1.3 + 0.2, end = start + 1.1;
    if (t >= start) { out.push({ id, label, state: (t >= end && !(hold && i === EVENTS.length - 2)) ? 'done' : 'running', seq: ++seq }); }
  });
  return out;
}

const HISTORY = [
  { id: 1, role: 'user', text: 'What is the weather in Bhubaneswar tomorrow?', time: iso(now - 86400e3) },
  { id: 2, role: 'assistant', text: 'Tomorrow in Bhubaneswar: 31°C and humid, with a 40% chance of an evening shower. Carry an umbrella if you are out after 5.\n\nSource: https://open-meteo.com/', time: iso(now - 86400e3 + 4000), work_events: [{ id: 'a', label: 'Request accepted', state: 'done', seq: 1 }, { id: 'b', label: 'Searching public sources', state: 'done', seq: 2 }, { id: 'c', label: 'Checking sources', state: 'done', seq: 3 }] },
  { id: 3, role: 'user', text: 'Remind me to renew the domain on Friday at 10am', time: iso(now - 3600e3) },
  { id: 4, role: 'assistant', text: 'Done. I will remind you on Friday at 10:00 AM (IST) to renew the domain. You can see or change it any time with “my reminders”.', time: iso(now - 3600e3 + 3000) }
];

const MEMBERS = [{ id: 'r1', name: 'Writistic launch crew', is_owner: true }];

async function web(path, init) {
  const body = init?.body ? JSON.parse(init.body) : undefined; const p = path.split('?')[0]; const q = new URLSearchParams(path.split('?')[1] || '');
  await new Promise(r => setTimeout(r, 120));
  switch (p) {
    case 'status': return json({ login_configured: true });
    case 'me': return json({ id: 7, name: 'Pratham', expires_at: Math.floor((Date.now() + 6e8) / 1000) });
    case 'conversations': return json({ conversations: [{ id: 'c1', title: 'Phones under ₹20,000' }, { id: 'c2', title: 'Invoice follow-up to Meera' }, { id: 'c3', title: 'Trip plan: Puri weekend' }] });
    case 'conversation-create': return json({ id: 'c' + Math.random().toString(36).slice(2, 6), title: 'New chat' });
    case 'history': case 'conversation-history': return json({ messages: HISTORY, has_more: false, before: null });
    case 'intent': {
      const t = (body.message || '').toLowerCase();
      if (/\bemail\b.*\bto\b|send .*mail/.test(t)) return json({ route: 'preview', args: { kind: 'email' } });
      if (/^export/.test(t)) return json({ route: 'export', args: { format: 'md' } });
      return json({ route: 'chat', args: {}, ticket: 'T' + Math.random().toString(36).slice(2) });
    }
    case 'chat': case 'upload': {
      if (mode === 'busy' && !reqs.has(body.request_id)) { reqs.set(body.request_id, { t: null, body, fails: 0 }); }
      const r = reqs.get(body.request_id) || (reqs.set(body.request_id, { t: null, body, fails: 0 }), reqs.get(body.request_id));
      if (mode === 'busy' && r.fails < 2) { r.fails++; throw new TypeError('Failed to fetch'); }
      if (r.t == null) r.t = Date.now();
      return json({ request_id: body.request_id, state: 'queued' }, 202);
    }
    case 'result': {
      const r = reqs.get(q.get('id')); if (!r || r.t == null) return json({ error: 'Request not found in your account.' }, 404);
      const t = (Date.now() - r.t) / 1000; const text = (r.body.message || '').toLowerCase(); const hold = mode === 'hold';
      const ev = progressAt(t, hold);
      if (hold || t < 7.2) return json({ request_id: q.get('id'), state: t < 0.4 ? 'queued' : 'running', progress: ev, draft: t > 3.2 ? ANSWER.split('\n').slice(0, 3).join('\n') : '', items: [] });
      const items = [{ kind: 'text', text: /chart|csv|table/.test(text) ? 'Here are the prices by city as a table and a chart. Open it to sort or download the CSV.' : ANSWER }];
      if (/chart|csv|table/.test(text)) items.push({ kind: 'artifact', mime: 'text/csv', name: 'prices-by-city.csv', data: csvB64() });
      if (/screenshot|computer|browser|open/.test(text)) items.push({ kind: 'artifact', mime: 'image/png', name: 'browser-step-3.png', data: pngB64('Poco X7 5G — Flipkart') });
      return json({ request_id: q.get('id'), state: 'done', progress: ev.map(e => ({ ...e, state: 'done' })), items });
    }
    case 'action-preview': return json({ review_id: 'rv1', hash: 'h1', kind: body.kind, expires_in: 600, text: 'From: demo@example.com\nTo: meera@example.com\nSubject: Invoice #2041 — gentle reminder\n\nHi Meera,\n\nA quick nudge on invoice #2041 (₹42,000, due 12 Oct). Happy to resend the PDF if that helps.\n\nThanks,\nPratham', html: '<div style="font-family:sans-serif;padding:16px"><p>Hi Meera,</p><p>A quick nudge on invoice #2041 (<b>₹42,000</b>, due 12 Oct). Happy to resend the PDF if that helps.</p><p>Thanks,<br>Pratham</p></div>', review_fields: { to: ['meera@example.com'], subject: 'Invoice #2041 — gentle reminder', body: 'Hi Meera,…' } });
    case 'action-confirm': await new Promise(r => setTimeout(r, 700)); return json({ state: body.decision === 'confirm' ? 'done' : 'cancelled', text: body.decision === 'confirm' ? 'Email sent from demo@example.com to meera@example.com.\nReceipt: provider accepted the message.' : 'Cancelled. Nothing was sent.', receipt: {} });
    case 'connections': return json({ google: 'demo@example.com', workspace: '', calendar_owner: true });
    case 'notifications': return json({ notifications: [
      { id: 'a'.repeat(64), text: 'Reminder: renew the domain (writistic.in). Friday 10:00.', created_at: iso(now - 1800e3), seen: false },
      { id: 'b'.repeat(64), text: 'Work complete: 12-page market scan is ready. Ask “show my files” to get it.', created_at: iso(now - 7200e3), seen: false },
      { id: 'c'.repeat(64), text: 'Morning digest: 3 tasks due today, 1 reminder, weather 31°C.', created_at: iso(now - 86400e3), seen: true }] });
    case 'notification-seen': return json({ ok: true });
    case 'proactive': return json(body ? { text: 'Saved. Check-ins and digests will arrive in this app.' } : { proactive: true, digest: 'morning', quiet_start: 22, quiet_end: 7, delivery: 'in-app Notifications', timezone: 'Asia/Calcutta' });
    case 'activity': return json({ activity: [
      { created_at: iso(now - 600e3), state: 'done', progress: [{ label: 'Request accepted', state: 'done' }, { label: 'Searching public sources', state: 'done' }, { label: 'Checking sources', state: 'done' }], items: [{ kind: 'text', text: 'Three phones stand out under ₹20,000 right now…' }] },
      { created_at: iso(now - 90000e3), state: 'done', progress: [{ label: 'Request accepted', state: 'done' }, { label: 'Opening the public browser', state: 'done' }], items: [{ kind: 'text', text: 'I opened the page and saved a screenshot.' }] }] });
    case 'rooms': return json({ notice: 'This room is shared. Every message is visible to all current and future members. No personal memory, files, Gmail, Calendar or other connected-account data is imported. Public information only. Do not post secrets.', rooms: MEMBERS });
    case 'rooms/history': return json({ messages: [{ id: 1, author_label: 'Member 3fa91c2e', role: 'user', text: 'Which shared-hosting plan is cheapest for a static site?', created_at: iso(now - 3600e3) }, { id: 2, author_label: 'Crayon', role: 'assistant', text: 'For a static site, free tiers like GitHub Pages or Cloudflare Pages cost nothing and are enough.', created_at: iso(now - 3590e3) }] });
    case 'rooms/create': return json({ id: 'r2', name: body.name, invite: 'Xk2p9QmLw3sVt8aNfRz1Jh7YdUc4EoBg6TiHn0MvAqW', notice: '' });
    case 'rooms/inspect': return json({ id: 'r3', name: 'Puri trip planners', notice: 'This room is shared with every current and future member.' });
    case 'rooms/join': return json({ id: 'r3', name: 'Puri trip planners', is_owner: false });
    case 'rooms/say': return json({ text: 'ok' });
    case 'mcp': return json(body ? { name: body.name, tools: [{ name: 'search' }] } : { notice: 'Connectors run on third-party servers. What you ask them may be shared with that server. Every call needs your review.', connectors: { 'docs-search': { tools: [{ name: 'search_docs' }, { name: 'open_page' }] } } });
    case 'private-read': return json({ text: 'Inbox (demo): 3 unread. Meera Das, “Invoice query”; Asin, “Cover draft v3”; Razorpay, “Settlement”.' });
    case 'connect': return json({ url: 'https://example.com/connect', text: 'Open the page to connect. This link is tied to your account.' });
    case 'logout': return json({ ok: true });
    case 'email/config': return json({ apiKey: 'demo' });
    case 'email/session': return json({ token: 'E'.repeat(43), expires_in: 604800, user: { id: 9, name: 'Demo user' } });
    default: return json({ error: 'Request not confirmed.' }, 404);
  }
}

/* Crayon-Web guest endpoints */
async function guest(url, init) {
  if (mode === 'busy') throw new TypeError('Failed to fetch');
  const u = new URL(url);
  if (u.pathname === '/api/chat') {
    const enc = new TextEncoder(); const text = 'Short version: a static site on GitHub Pages is free and fast. Add a custom domain only if you need one. That covers most personal and small-business sites.';
    return new Response(new ReadableStream({ async start(c) { c.enqueue(enc.encode('data: {"m":"Thinking"}\n\n')); for (const w of text.split(' ')) { await new Promise(r => setTimeout(r, 25)); c.enqueue(enc.encode('data: ' + JSON.stringify({ t: w + ' ' }) + '\n\n')); } c.enqueue(enc.encode('data: [DONE]\n\n')); c.close(); } }), { headers: { 'Content-Type': 'text/event-stream' } });
  }
  if (u.pathname === '/api/weather') return json({ place: 'Mumbai, India', temp: 31, feels: 36, humidity: 72, wind: 14, cond: 'Partly cloudy', days: [{ date: '2026-10-17', max: 33, min: 26, rain: 20 }, { date: '2026-10-18', max: 32, min: 26, rain: 30 }, { date: '2026-10-19', max: 33, min: 27, rain: 10 }], source: 'open-meteo.com' });
  if (u.pathname === '/api/fx') return json({ base: 'USD', to: 'INR', rate: 88.41, date: 'Sat, 17 Oct 2026 00:02', source: 'open.er-api.com' });
  if (u.pathname === '/api/stock') return json({ symbol: 'AAPL', name: 'Apple Inc.', price: 231.4, prev: 229.9, currency: 'USD', exchange: 'NasdaqGS', date: '2026-10-16 16:00 EDT', delayed: true, source: 'yahoo finance' });
  return json({ error: 'not found' }, 404);
}

const realFetch = window.fetch.bind(window);
window.__crayonFetch = async (url, init) => {
  const u = String(url);
  if (u.startsWith(API + '/web/')) { const r = await web(u.slice((API + '/web/').length), init); return r; }
  if (u.startsWith(WEB_API)) return guest(u, init);
  return realFetch(url, init);
};
window.__crayonDemo = true;
/* stand-in for the Firebase client (gstatic is not reachable in the test sandbox) */
window.__crayonEmailClient = { async signIn() { return { emailVerified: true }; }, async create() {}, async verify() {}, async reset() {}, async token() { return 'demo-id-token'; }, async deleteProvider() {}, async clear() {} };
