/* Shared UI primitives: status, toasts, sheets (dialogs), anchored menus */
import { $, el, icon } from './util.js';
import { on, emit } from './bus.js';

let statusTimer;
export function status(text) {
  const s = $('#status'); s.textContent = text || '';
  clearTimeout(statusTimer); if (text) statusTimer = setTimeout(() => { if (s.textContent === text) s.textContent = ''; }, 9000);
}
on('status', status);
export function toast(text) {
  const t = el('div', { class: 'toast' }, text); $('#toasts').append(t);
  setTimeout(() => t.remove(), 4200);
}
on('toast', toast);

/* A modal sheet. build(sheet, close) fills it. Returns { dialog, close } */
export function sheet(title, build, { cls = '' } = {}) {
  const d = el('dialog', { 'aria-label': title });
  const inner = el('div', { class: 'sheet ' + cls }, el('h2', {}, title));
  const close = () => { d.close(); d.remove(); };
  d.append(inner); $('#dialogs').append(d);
  d.addEventListener('cancel', e => { e.preventDefault(); close(); });
  d.addEventListener('click', e => { if (e.target === d) close(); });
  build(inner, close);
  d.showModal();
  return { dialog: d, close, inner };
}
export function field(label, { value = '', multiline = false, type = 'text', hint, attrs = {} } = {}) {
  const id = 'f' + Math.random().toString(36).slice(2, 8);
  const input = el(multiline ? 'textarea' : 'input', { id, class: multiline ? 'textarea' : 'input', value, type: multiline ? undefined : type, ...attrs });
  if (multiline) input.value = value;
  const wrap = el('div', { class: 'field' }, el('label', { for: id }, label), input, hint ? el('span', { class: 'hint' }, hint) : null);
  return { wrap, input };
}
export function button(text, onclick, cls = 'btn', ic) {
  const b = el('button', { type: 'button', class: cls, onclick }, ic ? icon(ic, 'sm') : null, text); return b;
}
/* Disable a button while an async job runs */
export async function busyBtn(b, fn) {
  b.disabled = true; b.classList.add('loading');
  try { return await fn(); } finally { b.disabled = false; b.classList.remove('loading'); }
}

/* anchored menu; items: [{label, hint, icon, checked, onclick}] */
let openMenu = null;
export function closeMenu() { openMenu?.remove(); openMenu = null; }
export function menu(anchor, items, { align = 'left', up = false } = {}) {
  closeMenu();
  const m = el('div', { class: 'menu', role: 'menu' });
  items.forEach(it => {
    const b = el('button', { type: 'button', role: it.checked != null ? 'menuitemradio' : 'menuitem', 'aria-checked': it.checked != null ? String(!!it.checked) : undefined,
      onclick: () => { closeMenu(); it.onclick?.(); } },
      it.icon ? icon(it.icon) : null, el('span', {}, it.label, it.hint ? el('small', {}, it.hint) : null));
    if (it.checked) b.append(el('span', { style: 'margin-left:auto' }, icon('check', 'sm')));
    m.append(b);
  });
  document.body.append(m); openMenu = m;
  const r = anchor.getBoundingClientRect(), mw = m.offsetWidth, mh = m.offsetHeight;
  let left = align === 'right' ? r.right - mw : r.left; left = Math.max(8, Math.min(left, innerWidth - mw - 8));
  let top = up ? r.top - mh - 6 : r.bottom + 6; if (top + mh > innerHeight - 8) top = Math.max(8, r.top - mh - 6);
  m.style.left = left + 'px'; m.style.top = top + 'px';
  m.querySelector('button')?.focus();
  m.addEventListener('keydown', e => {
    const bs = [...m.querySelectorAll('button')], i = bs.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { bs[(i + 1) % bs.length].focus(); e.preventDefault(); }
    if (e.key === 'ArrowUp') { bs[(i - 1 + bs.length) % bs.length].focus(); e.preventDefault(); }
    if (e.key === 'Escape') { closeMenu(); anchor.focus(); }
  });
  setTimeout(() => document.addEventListener('pointerdown', function h(e) { if (!m.contains(e.target)) { closeMenu(); } document.removeEventListener('pointerdown', h); }, { once: false }), 0);
  return m;
}
