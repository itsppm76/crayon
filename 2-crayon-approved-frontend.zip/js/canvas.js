/* CSV -> sortable table + bar chart, client side only */
import { el } from './util.js';
const NS = 'http://www.w3.org/2000/svg';
export function parseCsv(text) {
  const rows = []; let row = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
    else if (c === '"') q = true; else if (c === ',') { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some(x => x !== '')) rows.push(row); row = []; }
    else cur += c;
  }
  if (cur !== '' || row.length) { row.push(cur); rows.push(row); }
  const head = rows.shift() || [];
  const isNum = j => rows.length && rows.every(r => r[j] === '' || r[j] === undefined || !Number.isNaN(Number(String(r[j]).replace(/[,₹$%\s]/g, ''))));
  return { head, rows: rows.slice(0, 500), num: head.map((_, j) => isNum(j)) };
}
const toNum = v => Number(String(v).replace(/[,₹$%\s]/g, ''));
export function tableEl(t) {
  let sort = { j: -1, dir: 1 };
  const table = el('table', { class: 'data' }); const wrap = el('div', { class: 'table-wrap', tabIndex: 0, role: 'region', 'aria-label': 'Table' }, table);
  function draw() {
    const rows = sort.j < 0 ? t.rows : [...t.rows].sort((a, b) => (t.num[sort.j] ? toNum(a[sort.j]) - toNum(b[sort.j]) : String(a[sort.j]).localeCompare(String(b[sort.j]))) * sort.dir);
    table.replaceChildren(
      el('thead', {}, el('tr', {}, t.head.map((h, j) => el('th', { class: t.num[j] ? 'n' : '', 'aria-sort': sort.j === j ? (sort.dir > 0 ? 'ascending' : 'descending') : 'none', tabIndex: 0, onclick: () => { sort = { j, dir: sort.j === j ? -sort.dir : 1 }; draw(); }, onkeydown: e => { if (e.key === 'Enter') e.target.click(); } }, h)))),
      el('tbody', {}, rows.map(r => el('tr', {}, t.head.map((_, j) => el('td', { class: t.num[j] ? 'n' : '' }, r[j] ?? ''))))));
  }
  draw(); return wrap;
}
export function chartEl(t) {
  const nj = t.num.findIndex((n, j) => n && j > 0) >= 0 ? t.num.findIndex((n, j) => n && j > 0) : t.num.findIndex(n => n);
  if (nj < 0 || t.rows.length < 2) return el('span');
  const lj = nj === 0 ? 1 : 0; const rows = t.rows.slice(0, 12);
  const vals = rows.map(r => toNum(r[nj]) || 0); const max = Math.max(...vals, 1);
  const W = 360, H = 180, pad = 26, bw = (W - pad) / rows.length;
  const svg = document.createElementNS(NS, 'svg'); svg.setAttribute('viewBox', `0 0 ${W} ${H}`); svg.setAttribute('class', 'chart'); svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', `Bar chart of ${t.head[nj]} by ${t.head[lj]}`);
  let h = `<line class="axis" x1="${pad}" y1="${H - 22}" x2="${W}" y2="${H - 22}"/>`;
  rows.forEach((r, i) => { const bh = (vals[i] / max) * (H - 50); const x = pad + i * bw + 3; h += `<rect class="bar" x="${x}" y="${H - 22 - bh}" width="${Math.max(4, bw - 6)}" height="${bh}" rx="3"><title>${String(r[lj]).replace(/</g, '&lt;')}: ${vals[i]}</title></rect><text x="${x + (bw - 6) / 2}" y="${H - 8}" text-anchor="middle">${String(r[lj]).slice(0, 5).replace(/</g, '&lt;')}</text>`; });
  h += `<text x="2" y="12">${Math.round(max)}</text>`;
  svg.innerHTML = h; return svg;
}
