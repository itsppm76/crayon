const SVGNS = 'http://www.w3.org/2000/svg';
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k === 'dataset') Object.assign(n.dataset, v);
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    else if (k in n && k !== 'list' && k !== 'form') { try { n[k] = v; } catch { n.setAttribute(k, v); } }
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) n.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  return n;
}
export function icon(name, cls = '') {
  const s = document.createElementNS(SVGNS, 'svg');
  s.setAttribute('class', 'ico ' + cls); s.setAttribute('aria-hidden', 'true'); s.setAttribute('focusable', 'false');
  const u = document.createElementNS(SVGNS, 'use'); u.setAttribute('href', 'assets/icons.svg#i-' + name); s.append(u);
  return s;
}
export function iconBtn(name, label, onclick, cls = '') {
  const b = el('button', { type: 'button', class: 'icon-btn ' + cls, 'aria-label': label, title: label, onclick });
  b.append(icon(name)); return b;
}
export const sleep = ms => new Promise(r => setTimeout(r, ms));
export function randomId() {
  const b = new Uint8Array(32); crypto.getRandomValues(b);
  return btoa(String.fromCharCode(...b)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export async function challenge(s) {
  const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return btoa(String.fromCharCode(...new Uint8Array(d))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
export function fmtTime(sec) { const m = Math.floor(sec / 60), s = Math.floor(sec % 60); return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0'); }
export function b64ToBlobUrl(data, mime) {
  const bytes = Uint8Array.from(atob(data), c => c.charCodeAt(0));
  return URL.createObjectURL(new Blob([bytes], { type: mime }));
}
/* Safe auto-linking via text nodes, never innerHTML */
export function linkedText(node, text) {
  let last = 0;
  for (const m of text.matchAll(/https?:\/\/[^\s<>"']+/gi)) {
    const value = m[0].replace(/[.,!?;:)\]}]+$/, '');
    let u; try { u = new URL(value); } catch { continue; }
    if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password) continue;
    node.append(document.createTextNode(text.slice(last, m.index)));
    node.append(el('a', { href: u.href, target: '_blank', rel: 'noopener noreferrer', title: value }, u.hostname.replace(/^www\./, '')));
    last = m.index + value.length;
  }
  node.append(document.createTextNode(text.slice(last)));
}
/* Pull "Source:" / "Sources:" trailing lines out of an answer so they can be tucked under it */
export function splitSources(text) {
  const lines = String(text || '').split('\n'); const body = []; const sources = [];
  for (const line of lines) {
    const m = line.match(/^\s*(?:[-*•]\s*)?Sources?:\s*(.*)$/i);
    if (m) { for (const u of (m[1] || '').matchAll(/https?:\/\/[^\s<>"',)]+/g)) sources.push(u[0].replace(/[.,;:!?]+$/, '')); continue; }
    if (sources.length && /^\s*(?:[-*•\d.]+\s*)?(?:\[[^\]]+\]\()?https?:\/\//.test(line)) { for (const u of line.matchAll(/https?:\/\/[^\s<>"',)\]]+/g)) sources.push(u[0].replace(/[.,;:!?]+$/, '')); continue; }
    body.push(line);
  }
  const uniq = [...new Set(sources)].filter(u => { try { const x = new URL(u); return !x.username && !x.password; } catch { return false; } });
  return { text: body.join('\n').replace(/\n{3,}/g, '\n\n').trimEnd(), sources: uniq };
}
export const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return u; } };
export function greeting() {
  const h = new Date().getHours();
  return h < 5 ? 'Still up' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 22 ? 'Good evening' : 'Late night';
}
export const reduceMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
