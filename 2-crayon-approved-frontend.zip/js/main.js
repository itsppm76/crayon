import { DEMO } from './config.js';
import { $, el } from './util.js';
import { state, on, emit } from './bus.js';
if (DEMO) await import('./mock.js');
const [{ hydrateMascots }] = await Promise.all([import('./mascot.js')]);
hydrateMascots();
await import('./ui.js');
await import('./thread.js');
await import('./approval.js');
await import('./chat.js');
await import('./composer.js');
const Session = await import('./session.js');
await import('./auth.js');
const Welcome = await import('./welcome.js');
await import('./rail.js');
await import('./bench.js');
await import('./palette.js');
const { exportAs } = await import('./exports.js');
const { call } = await import('./api.js');
const { status } = await import('./ui.js');

on('export', f => { if (f === 'ask') $('#exportbtn').click(); else exportAs(f); });
const { menu } = await import('./ui.js');
$('#exportbtn').onclick = e => menu(e.currentTarget, [
  { label: 'PDF document', icon: 'file-pdf', onclick: () => exportAs('pdf') },
  { label: 'Word (.docx)', icon: 'file-doc', onclick: () => exportAs('docx') },
  { label: 'Markdown (.md)', icon: 'file-text', onclick: () => exportAs('md') },
  { label: 'Slides (.pptx)', icon: 'play', hint: 'Built from the last answer', onclick: () => exportAs('pptx') }
], { align: 'right' });

/* welcome shows only while the thread is empty */
const log = $('#log'), welcome = $('#welcome');
const syncWelcome = () => welcome.classList.toggle('hide', log.children.length > 0 && !!state.token);
new MutationObserver(syncWelcome).observe(log, { childList: true });
on('signed-in', syncWelcome); on('auth-changed', syncWelcome);

/* topbar border once scrolled */
$('#scroll').addEventListener('scroll', () => $('#topbar').classList.toggle('scrolled', $('#scroll').scrollTop > 4), { passive: true });

/* demo label: never let fixtures pass for real data */
if (DEMO) $('#topbar .grow').append(el('span', { class: 'chip on', title: 'Fixture data from js/mock.js, not a live backend' }, 'Demo data'));

Welcome.render();
const restored = await Session.restore();
if (!restored) {
  call('status').then(j => status(j.login_configured ? 'Sign in to continue.' : 'Sign-in is still being set up on the server, so private features stay locked.')).catch(() => status('Crayon’s host is waking up. Sign-in will work in a moment.'));
}
if (location.search.includes('source=pwa') || 'serviceWorker' in navigator && false) { /* reserved for PWA hooks */ }
